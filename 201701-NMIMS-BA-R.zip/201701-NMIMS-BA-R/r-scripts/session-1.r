#####
# script: session-1.r
# title : business analytic using r
# focus : intro & quick start
# author: Cyrus Lentin
# date  : 01-Oct-2015
#####

# working dir
setwd("D:/R-BA/R-Scripts")

# clear environment & history
rm(list = ls())
write("", file=".blank")
loadhistory(".blank")
unlink(".blank")

###
# assignment & print
###

cat("\014")
# assignment
x <- 1
# print
x
print(x)

###
# atomic classes of objects
###

cat("\014")
# numeric
x <- 3.333
x
is.numeric(x)
is.integer(x)

cat("\014")
# also numeric
x <- 9
x
is.numeric(x)
is.integer(x)

cat("\014")
# integer
x <- 9L
x
is.numeric(x)
is.integer(x)

cat("\014")
# logical
x <- TRUE
x
is.logical(x)

cat("\014")
# character / string
x <- "s"
x
is.character(x)
x <- "string"
x
is.character(x)

cat("\014")
# print undefined object
y

###
# vectors / list
###

cat("\014")
# empty vector
c <- vector()
c

cat("\014")
# vector of integers
c1 <- c(1L,2L,3L,4L,5L,6L,7L,8L,9L)
c1
is.vector(c1)
class(c1)
length(c1)
is.integer(c1[1])
is.numeric(c1[1])

cat("\014")
# vector of numeric / real numbers
c2 <- c(1,2,3,4,5,6,7,8,9)
c2
is.vector(c2)
class(c2)
length(c2)
is.integer(c2[1])
is.numeric(c2[1])

cat("\014")
# vector of numeric / real numbers
c3 <- c(1.1,2.2,3.3,4.4,5.5)
c3
is.vector(c3)
class(c3)
length(c3)
is.integer(c3[1])
is.numeric(c3[1])

cat("\014")
# vector of integers with :
# why integers?
c4 <- c(1:20)
c4
is.vector(c4)
class(c4)
length(c4)
is.integer(c4[1])
is.numeric(c4[1])

cat("\014")
# vector of integers with :
# why integers?
c4 <- 1:10
c4
is.vector(c4)
class(c4)
length(c4)
is.integer(c4[1])
is.numeric(c4[1])

cat("\014")
# vector of string
c5 <- c("aaa","bbb","ccc","ddd","xxx","yyy","zzz")
c5
is.vector(c5)
class(c5)
length(c5)
is.character(c5[1])

cat("\014")
# coercion numeric & char
y <- c(1.7, "a") ## character
y
class(y)
is.numeric(y[1])
is.character(y[1])
is.numeric(y[2])
is.character(y[2])

cat("\014")
# coercion logical & numeric
y <- c(TRUE, 2) ## numeric
y
class(y)
is.numeric(y[1])
is.character(y[1])
is.numeric(y[2])
is.character(y[2])

cat("\014")
# coercion logical & numeric
y <- c(TRUE, 0) ## numeric
y
class(y)
is.numeric(y[1])
is.character(y[1])
is.numeric(y[2])
is.character(y[2])

cat("\014")
# coercion logical & char
y <- c("a", TRUE) ## character
y
class(y)
is.numeric(y[1])
is.character(y[1])
is.numeric(y[2])
is.character(y[2])

cat("\014")
# conversion
z <- c(0:6)
z
class(z)
as.numeric(z)
class(z)
as.logical(z)
class(z)
as.character(z)
class(z)

cat("\014")
# conversion
z <- c(0:6)
z
class(z)
a <- as.numeric(z)
a
class(a)
b <- as.logical(z)
b
class(b)
c <- as.character(z)
c
class(c)

cat("\014")
# vector maths ops
c1 <- 1:9
c3 <- c1 + 2
c3
c3 <- c1 - 2
c3
c3 <- c1 * 2
c3
c3 <- c1 / 2
c3

cat("\014")
# vector maths ops
c1 <- 1:9
c2 <- 1:9
c3 <- c1 + c2
c3
c3 <- c1 - c2
c3
c3 <- c1 * c2
c3
c3 <- c1 / c2
c3

cat("\014")
# vector maths ops
# recycling rule - if two vectors are of unequal length, the shorter
# vector  will be recycled in order to match the longer vector.
c1 <- 1:9
c2 <- 1:3
c3 <- c1 + c2
c3
c3 <- c1 - c2
c3
c3 <- c1 * c2
c3
c3 <- c1 / c2
c3

cat("\014")
# vector maths
# recycling rule - if two vectors are of unequal length, the shorter
# vector  will be recycled in order to match the longer vector.
c1 <- 1:3
c2 <- 1:9
c3 <- c1 + c2
c3
c3 <- c1 - c2
c3
c3 <- c1 * c2
c3
c3 <- c1 / c2
c3

cat("\014")
# list
lst <- list(c1,c2,x,y)
lst
class(lst)
is.list(lst)

cat("\014")
# factors
vct <- c(1,0,1,0,0,0,0,1,1,1)
vct
vct.f <- factor(vct, labels = c("private", "public"))
vct.f
is.factor(vct.f)

cat("\014")
# factors
vct.f <- gl(3, 10)
vct.f
is.factor(vct.f)


###
# matrices
###

cat("\014")
# empty matirx
m <- matrix(nrow = 2, ncol = 3)
m
dim(m)
attributes(m)

cat("\014")
# how matrix is populated using a vector
m <- matrix(1:6, nrow = 2, ncol = 3)
m
class(m)

cat("\014")
# how matrix is populated using a vector
m <- matrix(1:9, nrow = 2, ncol = 3)
m
class(m)

cat("\014")
# how matrix is populated using a vector
m <- matrix(1:4, nrow = 2, ncol = 3)
m
class(m)

cat("\014")
# how matrix is populated using a vector & dim()
m <- 1:10
m
class(m)
dim(m) <- c(2, 5)
m
class(m)

### home assignment - start
cat("\014")
# matrix maths ops - sclar ops
m1 <- matrix(1:6, nrow = 2, ncol = 3)
i <- 2L
m2 <- m1 + i
m2
m2 <- m1 - i
m2
m2 <- m1 * i
m2
m2 <- m1 / i
m2

cat("\014")
# matrix maths ops - element ops
# rows & cols of both matrices should match
m1 <- matrix(1:6, nrow = 2, ncol = 3)
m2 <- matrix(1:6, nrow = 2, ncol = 3)
m3 <- m1 + m2
m3
m3 <- m1 - m2
m3
m3 <- m1 * m2
m3
m3 <- m1 / m2
m3

cat("\014")
# matrix maths ops - element ops
# error when rows & cols of both matrices don't match
m1 <- matrix(1:9, nrow = 3, ncol = 3)
m2 <- matrix(1:3, nrow = 1, ncol = 3)
m3 <- m1 + m2
m3
m3 <- m1 - m2
m3
m3 <- m1 * m2
m3
m3 <- m1 / m2
m3

cat("\014")
# matrix maths ops - matrix ops (dot product)
# imp rule - m1.row = m2.col else error
m1 <- matrix(1:6, nrow = 2, ncol = 3)
m2 <- matrix(1:6, nrow = 3, ncol = 2)
m3 <- m1 %*% m2
m3 #works
rm(m3)
m3 <- m1 %/% m2
m3 #error - no division allowed or possible
m1 <- matrix(1:6, nrow = 2, ncol = 3)
m2 <- matrix(1:6, nrow = 2, ncol = 3)
m3 <- m1 %*% m2
m3 #error - not allowed

cat("\014")
# identity matrix
m1 <- matrix(1:9, nrow = 3, ncol = 3)
m1
m2 <- matrix(c(1,0,0,0,1,0,0,0,1), nrow = 3, ncol = 3)
m2
m3 <- m1 %*% m2
m3

### home assignment - end

###
# data frames
###

cat("\014")
# first dfr
dfr <- data.frame(foo = 1:4, bar = c(T, T, F, F))
dfr
class(dfr)
names(dfr)
row.names(dfr)
attributes(dfr)
nrow(dfr)
ncol(dfr)

#####
# Subsetting
#####

cat("\014")
# subsetting vectors 1
x <- c("a", "b", "c", "d", "e", "f","a")
x[1]
x[2]
x[1:4]
x[x > "c"]

cat("\014")
# subsetting vectors 2
x <- c(101:110)
x[1]
x[2]
x[6:10]
x[x <= 5]

cat("\014")
# subsetting vectors 3
x <- c(1:10)
x[6:11]
x[-1]
x[-1:2]
x[-1:-2]

cat("\014")
# dataframe
dfr <- data.frame(foo = 1:9, bar = c(T, T, F, F,T, T, F, F, NA), buf=rep("string",9))
dfr

cat("\014")
dfr
# subsetting dataframes cols
dfr$foo                 # show column foo
class(dfr$foo)
dfr$bar                 # show column bar
class(dfr$bar)
dfr[,1]                 # get the first col
dfr[,2]                 # get the second  col
dfr[,ncol(dfr)]         # get last col

cat("\014")
# subsetting dataframes row
dfr[1,]                 # get the first row
dfr[3,]                 # get the third row
dfr[nrow(dfr),]         # get last row
row.names(dfr)
dfr["1",]               # get the row with name '1'
dfr['2',]               # get the row with name '2'

cat("\014")
# subsetting dataframes rows 2
dfr[1:2,]               # get the rows 1 to 2
dfr[-1,]                # get the all rows except 1
dfr[-3:-7,]             # get the all rows except 1 to 2

cat("\014")
# subsetting dataframes cols 2
dfr[,1:2]               # get the cols 1 to 2
dfr[,-1]                # get the all cols except 1
dfr[,-2:-3]             # get the all rows except 2 to 3
dfr[,-3:-3]             # get the all rows except 3 to 3


#####
# basic stats functions
#####

cat("\014")
# basic functions with vectors 1
set.seed(0)
x <- runif(10, min=0, max=10)
x
length(x)
summary(x)
sum(x)
min(x)
max(x)
median(x)
#mode(x)
sd(x)

cat("\014")
# basic functions with vectors 2
set.seed(0)
x <- runif(10, min=-10, max=10)
x
round(x)
floor(x)
ceiling(x)
trunc(x)