#####
# script: session-8.r
# title : business analytic using r
# focus : string manipulation
# author: Cyrus Lentin
# date  : 01-Oct-2015
#####

# working dir
setwd("D:/BA-R/R-Scripts")

# clear environment & history
rm(list = ls())
write("", file=".blank")
loadhistory(".blank")
unlink(".blank")

#####
# libraries
####
install.packages("stringr")
install.packages("stringr", dependencies=T, repos='http://cran.rstudio.com/')
install.packages("worldcloud")
install.packages("worldcloud", dependencies=T, repos='http://cran.rstudio.com/')

cat("\014")
#define vars
strX <- "The quick brown fox jumps over the new lazy dog"
strY <- "This is a whole NEW world that we are living in"
strZ <- "Hello Bill Gates! Why is your New Software called nth windows"
vcsX <- c(strX, strY, strZ)
vcsZ <- c(strZ, strY, strX)

cat("\014")
# substring
# substr(x, start, stop)
substr(strX, 11, 20)
strA <- substr(strX, 11, 20)
strA
class(strA)

cat("\014")
# substring
# substr(x, start, stop)
substr(vcsX,11,20)
vcsA <- substr(vcsX,11,20)
vcsA
class(vcsA)

cat("\014")
# string split
# strsplit(x, split)
sX <- strsplit(strX, " ")
sX
class(sX)
sX <- unlist(sX)
sX
class(sX)

cat("\014")
# string split
# strsplit(x, split)
strsplit(strX, "th")
strsplit(strY, "th")

cat("\014")
# string split
# strsplit(x, split)
vcsX
vX <- strsplit(vcsX, " ")
vX
class(vX)
vX <- unlist(vX)
vX
class(vX)

cat("\014")
# paste
# paste(..., sep = " ", collapse = NULL)
vcsK <- paste("Today is", as.character(Sys.Date()), sep=" ")
vcsK
class(vcsK)
vcsK <- paste(strX, strY, strZ, sep=" ")
vcsK
class(vcsK)
vcsK <- paste(vcsX, vcsZ, sep=" ")
vcsK
class(vcsK)
vcsK <- paste(vcsX, collapse=" ")
vcsK
class(vcsK)

cat("\014")
# paste
# cat(..., sep = " ")
vcsK <- cat("Today is", as.character(Sys.Date()), sep=" ")
vcsK
class(vcsK)
vcsK <-cat(strX, strY, strZ, sep=" ")
vcsK
class(vcsK)
vcsK <-cat(vcsX, vcsZ, sep=" ")
vcsK
class(vcsK)
vcsK <-cat(vcsX, sep=" ", collapse=" ")
vcsK
class(vcsK)

cat("\014")
# toupper
# toupper(x)
toupper(strX)
toupper(strY)
toupper(strZ)
toupper(vcsX)

cat("\014")
# tolower
# tolower(x)
tolower(strX)
tolower(strY)
tolower(strZ)
tolower(vcsX)

cat("\014")
# nchar
# nchar(x)
nchar(strX)
nchar(strY)
nchar(strZ)
nchar(vcsX)

cat("\014")
# sub / gsub
# sub(pattern, replacement, x, ignore.case=FALSE)
sub(" ", "_", strX)
sub(" ", "*", strY)
sub(" ", "~", strZ)
sub(" ", ".", vcsX)
sub("bill", "_", strZ)
sub("bill", "_", strZ, ignore.case=T)

cat("\014")
# sub / gsub
# gsub(pattern, replacement, x, ignore.case=FALSE)
gsub(" ", "_", strX)
gsub(" ", "*", strY)
gsub(" ", "~", strZ)
gsub(" ", ".", vcsX)
gsub("w", "_", strZ)
gsub("w", "_", strZ, ignore.case=T)

cat("\014")
# grepl
# grepl(pattern, x, ignore.case=FALSE)
grepl("new", strX)
grepl("new", strX, ignore.case=T)
grepl("new", strY)
grepl("new", strY, ignore.case=T)
grepl("new", strY)
grepl("new", strY, ignore.case=T)

cat("\014")
# grep
# grep(pattern, x, ignore.case=FALSE)
grep("new", strX)
grep("new", strX, ignore.case=T)
grep("new", strY)
grep("new", strY, ignore.case=T)
grep("new", vcsX)
grep("new", vcsX, ignore.case=T)

cat("\014")
# grepl
# pattern - Uppper or Lower or Mixed
grepl("[Nn][Ee][Ww]", strX)
grepl("[Nn][Ee][Ww]", strY)
grepl("[Nn][Ee][Ww]", strZ)
grepl("[Nn][Ee][Ww]", vcsX)

cat("\014")
# grepl
# pattern - starts with
grepl("^[Tt]h", strX)
grepl("^[Tt]h", strY)
grepl("^[Tt]h", strZ)
grepl("^[Tt]h", vcsX)

cat("\014")
# grepl
# pattern - ends with
grepl("dog$", strX)
grepl("dog$", strY)
grepl("dog$", strZ)
grepl("dog$", vcsX)

cat("\014")
# grepl
# pattern - wildcard . - th & any one other char
grepl("th.", strX)
grepl("th.", strY)
grepl("th.", strZ)
grepl("th.", vcsX)
strM <- "khkjhaskjhadkjfhdkth "
grepl("th.", strM)

cat("\014")
# grepl
# pattern - wildcard * 0 or more matches
grepl("th*", strX)
grepl("th*", strY)
grepl("th*", strZ)
grepl("th*", vcsX)
strM <- "khkjhaskjhadkjfhdkth"
grepl("th*", strM)

cat("\014")
# grepl
# pattern - wildcard + at least 1 match
grepl("th+", strX)
grepl("th+", strY)
grepl("th+", strZ)
grepl("th+", vcsX)
strM <- "khkjhaskjhadkjfhdkth"
grepl("th+", strM)

cat("\014")
# grepl
# literals
grepl("[[:alnum:]]", strX)
grepl("[[:alpha:]]", strX)
grepl("[[:blank:]]", strX)
grepl("[[:digit:]]", strX)
grepl("[[:lower:]]", strX)
grepl("[[:space:]]", strX)
grepl("[[:upper:]]", strX)
grepl("[[:cntrl:]]", strX)
grepl("[[:graph:]]", strX)
grepl("[[:print:]]", strX)
grepl("[[:punct:]]", strX)
grepl("[[:xdigit:]]", strX)

cat("\014")
# format
# use of trim
c(1:100)
format(1:100)
format(1:100, trim = TRUE)

cat("\014")
# format
# use of width / nsmall
format(13.7, width=10)
format(13.7, nsmall = 3)
format(c(6.0, 13.1), digits = 2)
format(c(6.0, 13.1), digits = 2, nsmall = 1)

cat("\014")
# format
# use of nsmall
format(13.7)
format(13.7, nsmall = 3)
format(c(6.0, 13.1), digits = 2)
format(c(6.0, 13.1), digits = 2, nsmall = 1)

cat("\014")
# format
# use of decimal mark
format(c(66.077, 1333.123), digits = 7, nsmall = 2, decimal=".")
format(c(66.077, 1333.123), digits = 7, nsmall = 2, decimal=",")

cat("\014")
# format
# use of big interval / big mark
format(c(987654321.077, 123456789.123), digits=14, nsmall=2, decimal=".", big.interval=3, big.mark=",")

cat("\014")
# format
# use of small interval / small mark
format(c(987654321.077666, 11123456789.123456), digits=14, nsmall=2, decimal=".", big.interval=3, big.mark=",", small.interval=2, small.mark="~")


cat("\014")
# format string
# use of width
format(c("Hello Wolrd!!!", "Internet Of Things"), width=20)
format(c("Hello Wolrd!!!", "Internet Of Things"), width=30)

cat("\014")
# format string
# use of justify
format(c("Hello Wolrd!!!", "Internet Of Things"), width=20, justify="right")
format(c("Hello Wolrd!!!", "Internet Of Things"), width=20, justify="centre")

cat("\014")
# sprintf with numeric
sprintf("%f", pi)
sprintf("%.3f", pi)
sprintf("%1.0f", pi)
sprintf("%5.1f", pi)
sprintf("%05.1f", pi)
sprintf("%+f", pi)
sprintf("% f", pi)
sprintf("%-10f", pi) # left justified
sprintf("%e", pi)
sprintf("%E", pi)

cat("\014")
# sprintf with string
sprintf("min 10-char string '%-10s'",
       c("a", "ABC", "and an even longer one"))
x <- 2349
sprintf("Substitute in a string or number: %s", x)
sprintf("Can have multiple %s occurrences %s", x, "- got it?")

#####
# stringr non-regex functions
#####

#install.packages("stringr")
library(stringr)

cat("\014")
# c
# str_c(..., sep = " ", [collapse=" "])
str_c("a", "b", "p", "p")
str_c("apple", "banana", "pear", "pineapple")
str_c("a", "b", "p", "p", sep=" ")
str_c("apple", "banana", "pear", "pineapple",sep=" ")
fruit <- c("apple", "banana", "pear", "pineapple")
str_c(fruit, sep=" ", collapse=" ")

cat("\014")
# join - deprecated
# str_join(..., sep = " ", [collapse=" "])
str_join(fruit, sep=" ", collapse=" ")
str_join("a", "b", "p", "p")
str_join("apple", "banana", "pear", "pineapple")
str_join("a", "b", "p", "p", sep=" ")
str_join("apple", "banana", "pear", "pineapple",sep=" ")
fruit <- c("apple", "banana", "pear", "pineapple")
str_join(fruit, sep=" ", collapse=" ")

cat("\014")
# count
# str_count(string, pattern = "")   ## regex allowed
fruit <- c("apple", "banana", "pear", "pineapple")
str_count(fruit, "a")
str_count(fruit, "^p")
str_count(fruit, "e$")

cat("\014")
# duplicate string # sort of rep()
# str_dup(string, times)
str_dup("This ", 5)
fruit <- c("apple", "pear", "banana", "pineapple")
str_dup(fruit, 2)
str_dup(fruit, 1:4)

cat("\014")
# length
# str_length(string)
fruit <- c("apple", "pear", "banana", "pineapple")
str_length(fruit)

cat("\014")
# order
# str_order(x, decreasing = FALSE, na_last = TRUE)
fruit <- c("apple", "banana", "pear", "pineapple", NA)
str_order(fruit)
str_order(fruit, decreasing=T)
str_order(fruit, decreasing=T, na_last=T)
str_order(fruit, decreasing=T, na_last=F)

cat("\014")
# sort
# str_sort(x, decreasing = FALSE, na_last = TRUE
str_sort(fruit)
str_sort(fruit, decreasing=T)
str_sort(fruit, decreasing=T, na_last=T)
str_sort(fruit, decreasing=T, na_last=F)

cat("\014")
# pad
# str_pad(string, width, side = c("left", "right", "both"), pad = " ")
fruit <- c("apple", "banana", "pear", "pineapple")
str_pad(fruit, 10, side="left", pad=" ")
str_pad(fruit, 20, side="right", pad=".")
str_pad(fruit, 30, side="both", pad="0")
str_pad(fruit, 10, side=c("left", "right", "both"), pad=c(" ",".","0"))

cat("\014")
# split
# str_split(string, pattern, n = Inf)
# str_split_fixed(string, pattern, n)
strX <- "The quick brown fox jumps over the new lazy dog"
strY <- "This is a whole NEW world that we are living in"
strZ <- "Hello Bill Gates! Why is your New Software called nth windows"
vcsX <- c(strX, strY, strZ)
vcsZ <- c(strZ, strY, strX)
str_split(vcsX, " ")
unlist(str_split(vcsX, " "))
str_split(vcsX, " ", 5)
unlist(str_split(vcsX, " ", 5))

cat("\014")
# sub
# str_sub(string, start=1L, end=-1L)
str_sub(vcsX, 11, 20)

cat("\014")
# tolower
# str_to_lower(string)
str_to_lower(strX)
str_to_lower(strY)
str_to_lower(strZ)
str_to_lower(vcsX)

cat("\014")
# toupper
# str_to_upper(string)
str_to_upper(strX)
str_to_upper(strY)
str_to_upper(strZ)
str_to_upper(vcsX)

cat("\014")
# totitle
# str_to_title(string)
str_to_title(strX)
str_to_title(strY)
str_to_title(strZ)
str_to_title(vcsX)

cat("\014")
# word
# word(string, start=1L, end=start, sep=" ")
word(vcsX,1)
word(vcsX,2)
word(vcsX,-1)
word(vcsX,2,5)
word(vcsX,5,-1)


#####
# stringr RegEx Functions
#####

cat("\014")
# detect
# str_detect(string, pattern)       ## regex allowed
fruit <- c("apple", "banana", "pear", "pineapple")
str_detect(fruit, "a")
str_detect(fruit, "e")
str_detect(fruit, c("a", "b", "p", "p"))

cat("\014")
# str_detect_all(string, pattern)       ## regex allowed
# detect
fruit <- c("apple", "banana", "pear", "pineapple")
str_detect_all(fruit, "a")
str_detect_all(fruit, "e")
str_detect_all(fruit, c("a", "b", "p", "p"))

cat("\014")
# detect all multi-char
# str_detect_all(string, pattern)       ## regex allowed
fruit <- c("apple", "banana", "pear", "pineapple")
str_detect_all(fruit, "ap")
str_detect_all(fruit, "le")
str_detect_all(fruit, c("a", "b", "p", "p"))

cat("\014")
# locate
# str_locate(string, pattern)
fruit <- c("apple", "banana", "pear", "pineapple")
str_locate(fruit, "a")
str_locate(fruit, "e")
str_locate(fruit, c("a", "b", "p", "p"))

cat("\014")
# locate all
# str_locate_all(string, pattern)
fruit <- c("apple", "banana", "pear", "pineapple")
str_locate_all(fruit, "a")
str_locate_all(fruit, "e")
str_locate_all(fruit, c("a", "b", "p", "p"))

cat("\014")
# locate multi-char
# str_locate(string, pattern)
fruit <- c("apple", "banana", "pear", "pineapple")
str_locate(fruit, "ap")
str_locate(fruit, "le")
str_locate(fruit, c("ap", "na", "ea", "le"))

cat("\014")
# locate all multi-char
# str_locate_all(string, pattern)
fruit <- c("apple", "banana", "pear", "pineapple")
str_locate_all(fruit, "ap")
str_locate_all(fruit, "le")
str_locate_all(fruit, c("ap", "na", "ea", "le"))

cat("\014")
# match & extract
string <- c("+919820018965", "+449820018965", "banana", "+15957947569",
            "+97153872876718", "apple", "+912333989187  ", "+914829523315",
            "+442399238115 and +448425664692", "Work: +915794997527",
            "$1000", "Home: +915433553679")
#phone <- "^[+91]{3}[0-9]{10}$"
phone <- "[+91]{3}[0-9]{10}"
str_match(string, phone)
str_extract(string, phone)

cat("\014")
# extract / extract_all
string <- c("+919820018965", "+449820018965", "banana", "+15957947569",
            "+97153872876718", "apple", "+912333989187  ", "+914829523315",
            "+442399238115 and +448425664692", "Work: +915794997527",
            "$1000", "Home: +915433553679")
#phone <- "^[+91]{3}[0-9]{10}$"
phone <- "[+91]{3}[0-9]{10}"
str_replace(string, phone, "+000000000000")

cat("\014")
# subset
# str_subset(string, pattern)
string <- c("+919820018965", "+449820018965", "banana", "+15957947569",
            "+97153872876718", "apple", "+912333989187  ", "+914829523315",
            "+442399238115 and +448425664692", "Work: +915794997527",
            "$1000", "Home: +915433553679")
#phone <- "^[+91]{3}[0-9]{10}$"
phone <- "[+91]{3}[0-9]{10}"
str_subset(string, phone)

#####
#word cloud
#####

cat("\014")
# load library
library(dplyr)
library(wordcloud)

cat("\014")
# simple word cloud
vcsWords <- c("The","quick","new","fox","jumps","over","the","lazy","brown","dog")
vcnFreqs <- c(15,30,18,23,34,56,45,32,21,10)
# wordcloud
wordcloud(vcsWords, vcnFreqs, random.order=F, max.words=10, colors=brewer.pal(8, "Dark2"))

#####
#text mining exercise
#####

cat("\014")
# clear environment & history
rm(list = ls())
write("", file=".blank")
loadhistory(".blank")
unlink(".blank")

cat("\014")
# read un-profile
vcsUNPrfLines <- readLines("./data/un-profile.txt")
# head
head(vcsUNPrfLines)
# line count = length of vector
intLineCount <- length(vcsUNPrfLines)
# split
lstUNPrfLines <- str_split(vcsUNPrfLines," ")
# words per line
vciUNPrfWperL <- unlist(lapply(lstUNPrfLines, length))
# unlist to get vector of words
vcsUNPrfWords <- unlist(lstUNPrfLines)
# total word count = length of vector
intWordCount <- length(vcsUNPrfWords)
# head & length
head(vcsUNPrfWords)

cat("\014")
# lower case
vcsUNPrfWords <- str_to_lower(vcsUNPrfWords)
# remove numbers
vcsUNPrfWords <- str_replace_all(vcsUNPrfWords, pattern="[[:digit:]]", "")
# remove punctuation
vcsUNPrfWords <- str_replace_all(vcsUNPrfWords, pattern="[[:punct:]]", "")
# remove white spaces
vcsUNPrfWords <- str_replace_all(vcsUNPrfWords, pattern="[[:space:]]", "")
# remove special chars
vcsUNPrfWords <- str_replace_all(vcsUNPrfWords, pattern="[~@#$%&-_=<>]", "")
# remove empty vectors
vcsUNPrfWords <- vcsUNPrfWords[vcsUNPrfWords != ""]
# hack & remove $
vcsUNPrfWords <- str_replace_all(vcsUNPrfWords, pattern="$", "")

cat("\014")
# make data frame
dfrUNPrfWords <- data.frame(vcsUNPrfWords)
colnames(dfrUNPrfWords) <- c("Words")
dfrUNPrfWords$Words <- as.character(dfrUNPrfWords$Words)
# normal word count
head(dfrUNPrfWords,10)
# summarise data
dfrUNPrfFreq <- dfrUNPrfWords %>% group_by(Words) %>% summarise(Freq=n())
# sort
dfrUNPrfFreq <- arrange(dfrUNPrfFreq, desc(Freq))
# wordcloud normal word count
wordcloud(dfrUNPrfFreq$Words[1:100], dfrUNPrfFreq$Freq[1:100], random.order=F, max.words=100, colors=brewer.pal(8, "Dark2"))

cat("\014")
# significant words only
# remove all words with len <= 2
dfrUNPrfWords <- filter(dfrUNPrfWords, str_length(Words)>2)
# remove all common words
# original found at http://en.wikipedia.org/wiki/Stop_words
vcsCmnWords <- c("all","also","and","any","are","but","can","cant","cry","due","etc","few","for","get","had","has","hasnt","have","her","here","hers","herself","him","himself","his","how","inc","into","its","ltd","may","nor","not","now","off","once","one","only","onto","our","ours","out","over","own","part","per","put","see","seem","she","than","that","the","their","them","then","thence","there","these","they","this","those","though","thus","too","top","upon","very","via","was","were","what","when","which","while","who","whoever","whom","whose","why","will","with","within","without","would","yet","you","your","yours","the")
dfrUNPrfWords <- filter(dfrUNPrfWords, !(Words %in% vcsCmnWords))
# remove all bad words ...
# original found at http://en.wiktionary.org/wiki/Category:English_swear_words
vcsBadWords <- c("arse","ass","asshole","bastard","bitch","bloody","bollocks","child-fucker","cunt","damn","fuck","goddamn","godsdamn","hell","motherfucker","shit","shitass","whore")
dfrUNPrfWords <- filter(dfrUNPrfWords, !(Words %in% vcsBadWords))
# summarise data
dfrUNPrfFreq <- dfrUNPrfWords %>% group_by(Words) %>% summarise(Freq=n())
# sort
dfrUNPrfFreq <- arrange(dfrUNPrfFreq, desc(Freq))
# remove sparse words ... words with Freq <= 2
dfrUNPrfFreq <- filter(dfrUNPrfFreq, Freq>2)
# wordcloud
wordcloud(dfrUNPrfFreq$Words[1:100], dfrUNPrfFreq$Freq[1:100], random.order=F, max.words=100, colors=brewer.pal(8, "Dark2"))


#####
#text mining exercise
#####

cat("\014")
# clear environment & history
rm(list = ls())
write("", file=".blank")
loadhistory(".blank")
unlink(".blank")

# values
strX <- "The quick brown fox jumps over the new lazy dog"
strY <- "This is a whole NEW world that we are living in"
strZ <- "Hello Bill Gates! Why is your New Software called nth windows"
vcsSent <- c(strX, strY, strZ)
strWords <- c("the", "a", "this", "that", "nth")
dfrSent <- data.frame(vcsSent)