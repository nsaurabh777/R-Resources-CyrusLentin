#####
# script: session-6.r
# title : business analytic using r
# focus : base graphs
# author: Cyrus Lentin
# date  : 01-Oct-2015
#####

# working dir
setwd("D:/R-BA/R-Scripts")

# clear environment & history
rm(list = ls())
write("", file=".blank")
loadhistory(".blank")
unlink(".blank")

#####
# libraries
####
# no libraries required

#####
# dataset
#####

cat("\014")
# explore data set to be used
dfrMtCars <- mtcars
head(dfrMtCars)
# important to create labels
dfrMtCars$gear <- factor(dfrMtCars$gear,levels=c(3,4,5), labels=c("3gears","4gears","5gears"))
dfrMtCars$am   <- factor(dfrMtCars$am,levels=c(0,1), labels=c("Manual","Automatic"))
dfrMtCars$cyl  <- factor(dfrMtCars$cyl,levels=c(4,6,8), labels=c("4cyl","6cyl","8cyl"))
nrow(dfrMtCars)

#####
# graphics parameters
#####

cat("\014")
# check general graphics parameters
par("las")
par("bg")
par("mar")
par("oma")
par("mfrow")
par("mfcol")

cat("\014")
# check comman graphics parameters
par("pch")
par("lty")
par("lwd")
par("col")
par("xlab")
par("ylab")

#####
# histogram
#####

cat("\014")
# simple histogram
hist(dfrMtCars$mpg)

cat("\014")
# colored histogram with different number of bins
hist(dfrMtCars$mpg, breaks=12)

cat("\014")
# colored histogram with different number of bins & with annotations
hist(dfrMtCars$mpg, breaks=12, col="red",
    main = "Histogram Of Milage",  ## title
    xlab = "Mileage MPG",          ## x-axis label
    ylab = "Frequency Count"       ## y-axis label
    )

#####
# scatterplot
#####

cat("\014")
# simple scatterplot
plot(dfrMtCars$wt, dfrMtCars$mpg, pch=19)

cat("\014")
# simple scatterplot with attach
attach(dfrMtCars)
plot(wt, mpg, pch=19, col="red")

cat("\014")
# simple scatterplot with annotations
plot(dfrMtCars$wt, dfrMtCars$mpg, pch=19, col="red",
    main="Scatterplot Example",
    xlab="Car Weight (Tons)",
    ylab="Miles Per Gallon"
    )

#####
# box plot
#####

cat("\014")
# boxplot of mpg by car cylinders
boxplot(mpg~cyl, data=dfrMtCars)

cat("\014")
# boxplot of mpg by car cylinders
boxplot(mpg~cyl, data=dfrMtCars, col="blue")

cat("\014")
# boxplot of mpg by car cylinders
boxplot(mpg~cyl, data=dfrMtCars, col="blue", notch=T)

cat("\014")
# boxplot of mpg by car cylinders
boxplot(mpg~cyl, data=dfrMtCars, col="blue", notch=T,
    main="Car Milage Data",
    xlab="Number of Cylinders",
    ylab="Miles Per Gallon"
    )

#####
# bar plot
#####

cat("\014")
# simple bar plot
# requies matrix
freqTable <- table(dfrMtCars$gear)
barplot(freqTable)

cat("\014")
# simple bar plot with color
# requies matrix
freqTable <- table(dfrMtCars$gear)
barplot(freqTable, col="yellow")

cat("\014")
# simple bar plot with color & annotations
# requies matrix
freqTable <- table(dfrMtCars$gear)
barplot(freqTable, col="yellow",
    main="Car Distribution",
    xlab="Number of Gears",
    ylab="Frequency Count"
    )

cat("\014")
# requies matrix
# simple horizontal bar plot with added labels
freqTable <- table(dfrMtCars$gear)
barplot(freqTable, col="yellow", horiz=TRUE,
    main="Car Distribution",
    xlab="Frequency Count",
    ylab="Number of Gears",
    names.arg=c("3 G", "4 G", "5 G")
    )

cat("\014")
# stacked bar plot
# requies matrix
freqTable <- table(dfrMtCars$am, dfrMtCars$gear)
barplot(freqTable, col=c("darkblue","red"))

cat("\014")
# stacked bar plot
# requies matrix
freqTable <- table(dfrMtCars$am, dfrMtCars$gear)
barplot(freqTable, col=c("darkblue","red"),
    main="Car Distribution by Gears and AM",
    xlab="Number of Gears",
    ylab="Frequency Count",
    legend = rownames(freqTable)
    )

cat("\014")
# grouped bar plot
# requies matrix
freqTable <- table(dfrMtCars$am, dfrMtCars$gear)
barplot(freqTable, col=c("darkblue","red"), beside=T)

cat("\014")
# grouped bar plot
# requies matrix
freqTable <- table(dfrMtCars$am, dfrMtCars$gear)
barplot(freqTable, col=c("darkblue","red"), beside=T,
    main="Car Distribution by Gears and AM",
    xlab="Number of Gears",
    ylab="Frequency Count",
    legend = c("Manual","Automatic")
    )

cat("\014")
# read nifty
dfrNifty <- read.csv("./data/nifty-data.csv", header=T, stringsAsFactors=F)

cat("\014")
# simple bar plot with annotations using x (labels) & y (numeric) data
# requires column as vector
dfrNifty.Tmp <- subset(dfrNifty, DateDate=="2014-12-01")
dfrNifty.Tmp <- dfrNifty.Tmp[1:10,]
barplot(dfrNifty.Tmp$ClosePrice, col=rainbow(10),
        #names.arg=dfrNifty.Tmp$Symbol,
        #legend = dfrNifty.Tmp$Symbol,
        names.arg=c(1:10),
        main="Share Price On 01-Dec-2014",
        xlab="Script Name",
        ylab="Close Price"
)

cat("\014")
# simple bar plot with annotations using x (labels) & TWO y (numeric) data
# requires matrix
dfrNifty.Tmp <- subset(dfrNifty, DateDate=="2014-12-01")
dfrNifty.Tmp <- dfrNifty.Tmp[1:10,]
m <- matrix(c(dfrNifty.Tmp$OpenPrice,dfrNifty.Tmp$ClosePrice),c(2,10), byrow=T)
barplot(m, col=c(4,5), beside=T,
    #names.arg=dfrNifty.Tmp$Symbol,
    legend = c("Open","Close"),
    names.arg=c(1:10),
    main="Share Price On 01-Dec-2014",
    xlab="Script Name",
    ylab="OPen / Close Price"
    )


#####
# line plot
#####

cat("\014")
# read nifty
dfrNifty <- read.csv("./data/nifty-data.csv", header=T, stringsAsFactors=F)
dfrNifty.Acc <- subset(dfrNifty, Symbol=="ACC")

cat("\014")
# line plot
plot(as.Date(dfrNifty.Acc$DateDate), dfrNifty.Acc$ClosePrice, type="l")
plot(as.Date(dfrNifty.Acc$DateDate), dfrNifty.Acc$ClosePrice, type="o")
plot(as.Date(dfrNifty.Acc$DateDate), dfrNifty.Acc$ClosePrice, type="p")
plot(as.Date(dfrNifty.Acc$DateDate), dfrNifty.Acc$ClosePrice, type="b")

cat("\014")
# line plot
plot(as.Date(dfrNifty.Acc$DateDate), dfrNifty.Acc$ClosePrice,
    col=3, type="l", lwd=1
    )
plot(as.Date(dfrNifty.Acc$DateDate), dfrNifty.Acc$ClosePrice,
    col=3, type="o", lwd=1
    )
plot(as.Date(dfrNifty.Acc$DateDate), dfrNifty.Acc$ClosePrice,
    col=3, type="o", lwd=1, pch=20
    )
plot(as.Date(dfrNifty.Acc$DateDate), dfrNifty.Acc$ClosePrice,
    col=3, type="o", lwd=1, lty="dashed", pch=20
    )
plot(as.Date(dfrNifty.Acc$DateDate), dfrNifty.Acc$ClosePrice,
    col=3, type="o", lwd=1, lty="dotted", pch=20
    )
plot(as.Date(dfrNifty.Acc$DateDate), dfrNifty.Acc$ClosePrice,
    col=3, type="o", lwd=1, pch=20,
    main="Share Movement",
    xlab="Date",
    ylab="Closing Price"
    )

cat("\014")
# multivariate line plot
par(mfrow=c(3,1))      # number of rows, number of columns
dfrNifty.Tmp <- subset(dfrNifty, Symbol=="ACC")
plot(as.Date(dfrNifty.Tmp$DateDate), dfrNifty.Tmp$ClosePrice,
     col=3, type="o", lwd=1, pch=20,
     main="Share Movement",
     xlab="Date",
     ylab="Closing Price"
    )
dfrNifty.Tmp <- subset(dfrNifty, Symbol=="LT")
plot(as.Date(dfrNifty.Tmp$DateDate), dfrNifty.Tmp$ClosePrice,
     col=4, type="o", lwd=1, pch=20,
     main="Share Movement",
     xlab="Date",
     ylab="Closing Price"
    )
dfrNifty.Tmp <- subset(dfrNifty, Symbol=="LUPIN")
plot(as.Date(dfrNifty.Tmp$DateDate), dfrNifty.Tmp$ClosePrice,
     col=5, type="o", lwd=1, pch=20,
     main="Share Movement",
     xlab="Date",
     ylab="Closing Price"
    )
par(mfrow=c(1,1))      # number of rows, number of columns

cat("\014")
# multivariate line plot
dfrNifty.Tmp <- subset(dfrNifty, Symbol=="ACC")
plot(as.Date(dfrNifty.Tmp$DateDate), dfrNifty.Tmp$ClosePrice,
    col=3, type="o", lwd=1, pch=20, xlab ="", ylab="",
    ylim=(c(1300,1800))
    )
par(new=T)
dfrNifty.Tmp <- subset(dfrNifty, Symbol=="LT")
plot(as.Date(dfrNifty.Tmp$DateDate), dfrNifty.Tmp$ClosePrice,
    col=4, type="o", lwd=1, pch=20, xlab ="", ylab="", axes=F,
    ylim=(c(1300,1800))
    )
par(new=T)
dfrNifty.Tmp <- subset(dfrNifty, Symbol=="LUPIN")
plot(as.Date(dfrNifty.Tmp$DateDate), dfrNifty.Tmp$ClosePrice,
     col=5, type="o", lwd=1, pch=20, xlab ="", ylab="", axes=F,
     ylim=(c(1300,1800))
    )
title(main="Share Movement",
    xlab="Date",
    ylab="Closing Price"
    )
legend("topright",legend=c("ACC","LT","Lupin"),
    col=c(3,4,5),
    lty=c(1,1,1),
    lwd=c(1,1,1),
    cex=0.6
    )


#####
# misc
#####

cat("\014")
# more than one plot in a window
par(mfrow=c(1,2))      # number of rows, number of columns
# colored histogram with different number of bins & with annotations
hist(dfrMtCars$mpg, breaks=12, col = "red",
     main = "Histogram Of Milage",  ## title
     xlab = "Mileage MPG",          ## x-axis label
     ylab = "Frequency Count"       ## y-axis label
)
# simple scatterplot with annotations
attach(dfrMtCars)
plot(wt, mpg, pch=19, col="red",
     main="Scatterplot Example",
     xlab="Car Weight (Tons)",
     ylab="Miles Per Gallon"
)

cat("\014")
# more than one plot in a window
par(mfrow=c(1,3))      # number of rows, number of columns
# colored histogram with different number of bins & with annotations
hist(dfrMtCars$mpg, breaks=12, col = "red",
     main = "Histogram Of Milage",  ## title
     xlab = "Mileage MPG",          ## x-axis label
     ylab = "Frequency Count"       ## y-axis label
)
# simple scatterplot with annotations
attach(dfrMtCars)
plot(wt, mpg, pch=19, col="red",
     main="Scatterplot Example",
     xlab="Car Weight (Tons)",
     ylab="Miles Per Gallon"
)
# boxplot of mpg by car cylinders
boxplot(mpg~cyl, data=dfrMtCars, col="blue", notch=T,
        main="Car Milage Data",
        xlab="Number of Cylinders",
        ylab="Miles Per Gallon"
)

cat("\014")
# more than one plot in a window
par(mfrow=c(2,2))      # number of rows, number of columns
# colored histogram with different number of bins & with annotations
hist(dfrMtCars$mpg, breaks=12, col = "red",
     main = "Histogram Of Milage",  ## title
     xlab = "Mileage MPG",          ## x-axis label
     ylab = "Frequency Count"       ## y-axis label
)
# simple scatterplot with annotations
attach(dfrMtCars)
plot(wt, mpg, pch=19, col="red",
     main="Scatterplot Example",
     xlab="Car Weight (Tons)",
     ylab="Miles Per Gallon"
)
# boxplot of mpg by car cylinders
boxplot(mpg~cyl, data=dfrMtCars, col="blue", notch=T,
        main="Car Milage Data",
        xlab="Number of Cylinders",
        ylab="Miles Per Gallon"
)
# grouped bar plot
freqTable <- table(dfrMtCars$vs, dfrMtCars$gear)
barplot(freqTable, col=c("darkblue","red"), beside=T,
        main="Car Distribution by Gears and VS",
        xlab="Number of Gears",
        ylab="Frequency Count",
        legend = c("VS=0","VS=1")
)

cat("\014")
# write to png
png("dfrMtCars.png", width = 500, height = 500, res = 72)
par(mfrow=c(1,2))      # number of rows, number of columns
# colored histogram with different number of bins & with annotations
hist(dfrMtCars$mpg, breaks=12, col = "red",
     main = "Histogram Of Milage",  ## title
     xlab = "Mileage MPG",          ## x-axis label
     ylab = "Frequency Count"       ## y-axis label
)
# simple scatterplot with annotations
attach(dfrMtCars)
plot(wt, mpg, pch=19, col="red",
     main="Scatterplot Example",
     xlab="Car Weight (Tons)",
     ylab="Miles Per Gallon"
)
dev.off()

cat("\014")
# write to pdf
pdf("dfrMtCars.pdf")
par(mfrow=c(1,2))      # number of rows, number of columns
# colored histogram with different number of bins & with annotations
hist(dfrMtCars$mpg, breaks=12, col = "red",
     main = "Histogram Of Milage",  ## title
     xlab = "Mileage MPG",          ## x-axis label
     ylab = "Frequency Count"       ## y-axis label
)
# simple scatterplot with annotations
attach(dfrMtCars)
plot(wt, mpg, pch=19, col="red",
     main="Scatterplot Example",
     xlab="Car Weight (Tons)",
     ylab="Miles Per Gallon"
)
dev.off()

#####
# final
#####
plot(dfrMtCars)

