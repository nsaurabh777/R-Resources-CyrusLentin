#####
# script: session-3.r
# title : business analytic using r
# focus : writing data / date-time functions
# author: Cyrus Lentin
# date  : 01-Oct-2015
#####

# working dir
setwd("D:/R-BA")

# clear environment & history
rm(list = ls())
write("", file=".blank")
loadhistory(".blank")
unlink(".blank")

#####
# write csv
####
cat("\014")
# data frame
set.seed(0)
dfr <- data.frame(foo=1:100, bar=x <- runif(10, min=0, max=10), buf=rnorm(100))
head(dfr)
write.csv(dfr,"filename.csv",row.names=F)
file.show("filename.csv")

#####
# write lines after reading text file
#####
cat("\014")
# readLines
vcsUNProfile <- readLines("./data/un-profile.txt")
head(vcsUNProfile)
length(vcsUNProfile)
vcsUNProfile <- substr(vcsUNProfile,1,50)
writeLines(vcsUNProfile,"filename.txt")
file.show("filename.txt")

#####
# write lines after reading URL
####
cat("\014")
# readLines to read URL
conGoogle <- url("https://en.wikipedia.org/wiki/Google", "r")
vcsGoogle <- readLines(conGoogle)
close(conGoogle)
length(vcsGoogle)
head(vcsGoogle)
writeLines(vcsGoogle,"filename.html")
file.show("filename.html")

#####
# write rds
####
cat("\014")
# data frame
set.seed(0)
dfr <- data.frame(foo=1:100, bar=x <- runif(10, min=0, max=10), buf=rnorm(100))
head(dfr)
saveRDS(dfr,"filename.rds")
file.show("filename.rds")


cat("\014")
drf <- NA
# data frame
drf <- readRDS("filename.rds")
head(drf)

#####
# date / time
#####

cat("\014")
# date yyyy-mm-dd hh:mm:ss
datX <- as.Date("2015-10-01 13:45:32")
datX
class(datX)
# POSIXlt yyyy-mm-dd hh:mm:ss
xltX <- as.POSIXlt("2015-10-01 13:45:32")
xltX
class(xltX)
# POSIXct yyyy-mm-dd hh:mm:ss
xctX <- as.POSIXct("2015-10-01 13:45:32")
xctX
class(xctX)
Sys.time()
class(Sys.time())

#####
# extract date / time using format()
#####

cat("\014")
# standard date format
format(Sys.time(), "%c")
# mm/dd/yy format
format(Sys.time(), "%D")
# yyyy-mm-dd - iso 8601 format
format(Sys.time(), "%F")
# day of week
format(Sys.time(), "%a")
format(Sys.time(), "%A")
# day of month
format(Sys.time(), "%d")
# month
format(Sys.time(), "%m")
format(Sys.time(), "%b")
format(Sys.time(), "%B")
# year
format(Sys.time(), "%y")
format(Sys.time(), "%Y")
# full date
format(Sys.time(), "%a %d-%b-%Y")
format(Sys.time(), "%a %d-%m-%Y")

# extract date / time using format()
cat("\014")
# time
format(Sys.time(), "%X")
# time to second accuracy
format(Sys.time(), "%H:%M:%S")
# time to sub-second accuracy (if supported by the OS)
format(Sys.time(), "%H:%M:%OS3")
# locale-specific version of date / time
format(Sys.time(), "%a %b %d %Y %X %Z")

#####
# system.time()
# proc.time()
#####
cat("\014")
# system.time
vctProcTime <- system.time({
    dfrWordFreq <- read.csv("./data/word-freq.csv", header=T, stringsAsFactors=F)
})
vctProcTime
vctProcTime[1]
# proc.time
vctProcStrt <- proc.time()
dfrWordFreq <- read.csv("./data/word-freq.csv", header=T, stringsAsFactors=F)
vctProcEnds <- proc.time()
vctProcEnds - vctProcStrt
vctProcEnds[1] - vctProcStrt[1]


#####
# swirl
#####
install.packages("swirl")
library(swirl)
swirl()