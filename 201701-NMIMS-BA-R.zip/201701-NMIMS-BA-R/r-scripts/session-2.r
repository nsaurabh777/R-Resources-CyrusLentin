#####
# script: session-2.r
# title : business analytic using r
# focus : reading & checking data
# author: Cyrus Lentin
# date  : 01-Oct-2015
#####


# working dir
setwd("D:/R-BA")

# clear environment & history
rm(list = ls())
write("", file=".blank")
loadhistory(".blank")
unlink(".blank")

#####
# missing values
#####

cat("\014")
# check NA, NaN, Inf
numX <- NA
is.na(numX)
# check NAN
numX <- 0 / 0
is.na(numX)
is.nan(numX)
# check inf
numX <- 1 / 0
is.na(numX)
is.infinite(numX)

cat("\014")
#cleaning NAs from single vector
vciX <- c(1, 2, NA, 4, NA, 5)
vciX
vcbBad <- is.na(vciX)
vcbBad
vciX[!vcbBad]

cat("\014")
#cleaning NAs from multiple vector
vciX <- c(1, 2, NA, 4, NA, 5)
vciX
vcsY <- c("a", "b", NA, "d", "e", NA)
vcsY
vcbGood <- complete.cases(vciX, vcsY)
vcbGood
vciX[vcbGood]
vcsY[vcbGood]

#####
# Basic Funtions With Data Frames
####

cat("\014")
# data frame
set.seed(0)
dfr <- data.frame(foo=1:10, bar=runif(10, min=0, max=100), buf=rnorm(10))
dfr

cat("\014")
# basic functions with data frame
names(dfr)
head(dfr)
tail(dfr)
length(dfr)
length(dfr$foo)
nrow(dfr)
ncol(dfr)
attributes(dfr)

cat("\014")
# basic functions with data frame
round(dfr$bar)
floor(dfr$bar)
ceiling(dfr$bar)
trunc(dfr$bar)

cat("\014")
# basic functions with data frame
sum(dfr$bar)
min(dfr$bar)
max(dfr$bar)
median(dfr$bar)
#mode(dfr$bar)
sd(dfr$bar)

cat("\014")
# basic functions with data frame
summary(dfr)
data.frame(foo.sd=sd(dfr$foo),bar.sd=sd(dfr$bar),buf.sd=sd(dfr$buf))

#####
# Ready To Use R Datasets
####

cat("\014")
library(datasets)
data()

cat("\014")
# use airquality dataset
airquality
head(airquality)
nrow(airquality)

cat("\014")
# get dataset of complete rows
vcbGoodAir <- complete.cases(airquality)
vcbGoodAir
dfrGoodAir <- airquality[vcbGoodAir, ]
head(dfrGoodAir)
nrow(dfrGoodAir)


#####
# read csv
####

cat("\014")
# use read.csv
dfrNifty <- read.csv("./data/nifty-data.csv", header=T, stringsAsFactors=F)
head(dfrNifty)
View(dfrNifty)
attributes(dfrNifty)
summary(dfrNifty)
nrow(dfrNifty)
ncol(dfrNifty)

#####
# read txt using readLines
####
cat("\014")
# readLines
vcsUNProfile <- readLines("./data/un-profile.txt")
#vcsUNProfile
head(vcsUNProfile)
length(vcsUNProfile)

#####
# view files
####
cat("\014")
# view files
file.show("session-1.r")
file.show("./data/un-profile.txt")
file.show("./data/nifty-data.csv")

#####
# read URL using readLines
####
cat("\014")
# readLines to read URL
conGoogle <- url("http://www.google.com/", "r")
vcsGoogle <- readLines(conGoogle)
close(conGoogle)
length(vcsGoogle)
head(vcsGoogle,10)
vcsGoogle[7]

#####
# Control Structures
#####

cat("\014")
# Control Structures - if
intX <- 0
if ( intX == 0 ) {
    print("X is Zero")
} else {
    print("X is NonZero")
}
if ( intX > 0 ) {
    print("X is Positive")
} else if ( intX < 0 ) {
    print("X is Negative")
} else {
    print("X is Zero")
}

cat("\014")
# Control Structures - for
vcsX <- c("Rohan","is","a","good","boy","Disha","is","a","bad","girl")
vcsX
for( i in 1:10 ) {
    print(i)
}
for( i in 1:5 ) {
    print(vcsX[i])
}
for( i in 6:10 ){
    print(vcsX[i])
}
for( i in seq_along(vcsX) ) {
    print(vcsX[i])
}
for(i in vcsX ) {
    print(i)
}
for(i in seq(from=1, to=10, by=2)){
    print(i)
}


cat("\014")
# Control Structures - while
intCount <- 0
while( intCount < 10 ) {
    print(intCount)
    intCount <- intCount + 1
}

intZ <- 5
while ( intZ >= 3 && intZ <= 10 ) {
    print(intZ)
    intCoin <- rbinom(1, 1, 0.5) ## returns either 0 or 1
    if(intCoin == 1) {
        intZ <- intZ + 1
    } else {
        intZ <- intZ - 1
    }
}


cat("\014")
# Control Structures - repeat
# note the only way to exit a repeat or while(T) loop is "break"
intX <- 1
repeat {
    print(intX)
    if( intX >= 10 ) {
        break
    } else {
        intX <- intX +1
    }
}

cat("\014")
# Control Structures - while(T)
# note the only way to exit a repeat or while(T) loop is "break"
intX <- 1
while ( TRUE ) {
    print(intX)
    if( intX >= 10 ) {
        break
    } else {
        intX <- intX +1
    }
}

# Control Structures flow controls - next / break
# next is used to skip an iteration of a loop
for(intX in 1:100) {
    if(intX <= 20) {
        ## Skip the first 20 iterations
        next
    }
    print(intX)
    if(intX == 30) {
        ## exit the loop
        break
    }
}

#####
# User Defined Function
#####

cat("\014")
# simple function without return statement
addNumbers <- function(numA, numB) {
    numSum <- numA + numB
    numSum
}
addNumbers(1,2)

cat("\014")
# simple function with return statement
addNumbers <- function(numA, numB) {
    numSum <- numA + numB
    return (numSum)
}
addNumbers(1,2)

cat("\014")
# simple function with two return statement
addNumbers <- function(numA, numB=0) {
    if ( (numA==0) && (numB==0) ) {
        return (NA)
    }
    numSum <- numA + numB
    return (numSum)
}
addNumbers(0)
addNumbers(1)
addNumbers(1,2)

cat("\014")
# function with 3 args
getNumber <- function(ones, tens, huns) {
    numThis <- ones + 10 * tens + 100 * huns
    return (numThis)
    }
# function call with positional args
getNumber (1,2,3)

cat("\014")
# function with 3 args
getNumber <- function(ones, tens, huns) {
    numThis <- ones + 10 * tens + 100 * huns
    return (numThis)
}
# function call with partial args
getNumber(1,2) ### throws error ... no arg defaults
getNumber(1,2,) ### throws error ... no arg defaults
getNumber(1,,3) ### throws error ... no arg defaults


cat("\014")
# function with 3 args
getNumber <- function(ones=0, tens=0, huns=0) {
    numThis <- ones + 10 * tens + 100 * huns
    return (numThis)
}
# function call with positional args
getNumber (1,2) ### works ... arg defaults provided

cat("\014")
# function with 3 args
getNumber <- function(ones=0, tens=0, huns=0) {
    numThis <- ones + 10 * tens + 100 * huns
    return (numThis)
}
# function call with named args
getNumber (huns=1,tens=2) ### works ... arg defaults provided

