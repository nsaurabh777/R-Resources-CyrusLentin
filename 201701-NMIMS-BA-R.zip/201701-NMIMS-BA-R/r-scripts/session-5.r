#####
# script: session--5.r
# title : business analytic using r
# focus : .md & .rmd
# author: Cyrus Lentin
# date  : 01-Oct-2015
#####

# working dir
setwd("D:/R-BA/R-Scripts")

# clear environment & history
rm(list = ls())
write("", file=".blank")
loadhistory(".blank")
unlink(".blank")

#####
# create test.rmd file
# follow
# cut-paste the below code test.rmd
#####
**** test.rmd - start - not to be included in the test.rmd file

# This is the main heading
## This is a secondary heading
### This is a tertiary heading

**This text will appear bold!**
__This text will also appear bold!__

*This text will appear in italics!*
_This text will also appear in italics!_

Ordered Lists
1. first item in list
2. second item in list
3. third item in list

Unordered Lists - 1
* first item in list
* second item in list
* third item in list

Unordered Lists - 2
- first item in list
- second item in list
- third item in list

Block Quote
> Ordered Lists
> 1. first item in list
> 2. second item in list
> 3. third item in list
> Unordered Lists
> - first item in list
> - second item in list
> - third item in list

Block Code - 1
	> Ordered Lists
	> 1. first item in list
	> 2. second item in list
	> 3. third item in list
	> Unordered Lists
	> - first item in list
	> - second item in list
	> - third item in list

Block Code - 2
```
> Ordered Lists
> 1. first item in list
> 2. second item in list
> 3. third item in list
> Unordered Lists
> - first item in list
> - second item in list
> - third item in list
```

Image
![RStudio Logo](https://www.rstudio.com/wp-content/uploads/2014/03/blue-125.png)

Links
[RStudio](http://www.rstudio.com/)
[Maexdata](http://www.maexadata.in/)

**** test.rmd - end - not to be included in the test.rmd file


**** test.rmd - before code start

#### knitr Global Options
```{r knit_opts, echo=TRUE}
# for development
knitr::opts_chunk$set(echo=TRUE, eval=TRUE, error=TRUE, warning=TRUE, message=TRUE, cache=FALSE, tidy=FALSE, fig.path='figures/')
# for production
#knitr::opts_chunk$set(echo=TRUE, eval=TRUE, error=FALSE, warning=FALSE, message=FALSE, cache=FALSE, tidy=FALSE, fig.path='figures/')
```

#### Load Libraries
```{r load_libs, echo=TRUE}
library(tidyr)
library(dplyr)
```

**** test.rmd - before code end


**** test.rmd - after plot - start

```{r max_cars}
maxSpeedVal <- max(cars$speed)
maxDistsVal  <- max(cars$dist)
```

The maximum speed is `r maxSpeedVal`
The maximum dist  is `r maxDistsVal`

**<<< End Of Report >>>**

**** test.rmd - after plot - ends

