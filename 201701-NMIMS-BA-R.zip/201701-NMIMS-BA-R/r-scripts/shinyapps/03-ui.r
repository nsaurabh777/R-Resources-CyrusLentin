# 03-ui.r
# panel width

# load library
library(shiny)

# Define UI for application that draws a histogram
shinyUI(fluidPage(

    # Application title
    titlePanel("Hello Shiny!"),

    # Sidebar with a slider input for the number of bins
    sidebarPanel(width=3,
        sliderInput("inpBinCount", "Number COunt",
            min=1, max=5, value=3),
        selectInput("inpColNames", label="Select Column",
            choices=c("Ozone","Solar.R","Temp","Wind"), selected=1)
    ),

    # Show a plot of the generated distribution
    mainPanel(width=9,
        plotOutput("pltHistogram")
    )

))