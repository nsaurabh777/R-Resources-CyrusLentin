# 02-app.r
# panels - titlePanel / sidebarPanel / mainPanel
# simple html tags 
# view source after html is generated

library(shiny)

ui <- fluidPage(

    # application title
    titlePanel("Hello Shiny!"),

    # side bar panel
    sidebarPanel(
        tags$h1("Side Bar"),
        tags$p("Our Inputs Controls Will Go Here"),
        tags$p("First paragraph"),
        tags$p("Second paragraph"),
        tags$p("Third paragraph")
    ),

    # main panel
    mainPanel(
        tags$h1("Main Panel Bar"),
        tags$p("Our Output Data / Graphs Will Go Here"),
        tags$p("First paragraph"),
        tags$p("Second paragraph"),
        tags$p("Third paragraph")
    )
)

server <- function(input, output) {}

shinyApp(ui = ui, server = server)
