# 03-app.r
# slider input
# plotOutput & renderPlot
# notice where libraries & datasets are loaded

#
library(shiny)
library(ggplot2)

# load dataset
dfrAirQuality <- airquality

ui <- fluidPage(

    # application title
    titlePanel("Hello Shiny!"),

    # side bar panel
    sidebarPanel(
        sliderInput("inpBinCount", "Number of bins:",
                    min=1, max=17, value = 9)
    ),

    # main panel
    mainPanel(
        plotOutput("pltHistogram")
    )
)

server <- function(input, output) {

    output$pltHistogram <- renderPlot({
        # plot col
        intBinCount <- input$inpBinCount
        vctPlotCols <- dfrAirQuality$Temp
        # draw the histogram with the specified number of bins
        hist(vctPlotCols, breaks=intBinCount, col='blue', border='white')
    })

}

shinyApp(ui = ui, server = server)
