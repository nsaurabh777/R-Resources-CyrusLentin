# 01-server.r
# ur.r / server.r as seperate files
# slider input
# plotOutput & renderPlot
# notice where libraries & datasets are loaded
# shinyServer

# load library
library(shiny)
library(ggplot2)

# load dataset
dfrAirQuality <- airquality

# define server logic required to draw a histogram
shinyServer(function(input, output) {

	# render plot
    output$pltHistogram <- renderPlot({
        # plot col
        intBinCount <- input$inpBinCount
        vctPlotCols <- dfrAirQuality$Temp
        # draw the histogram with the specified number of bins
        hist(vctPlotCols, breaks=intBinCount, col='blue', border='white')
    })
})