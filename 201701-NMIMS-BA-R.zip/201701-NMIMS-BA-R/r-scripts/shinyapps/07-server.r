# 07-server.r
# renderPrint / verbatimTextOutput

# load library
library(shiny)
library(ggplot2)
library(dplyr)

# load dataset
dfrAirQuality <- airquality

#
glblInstance <- 0

# define server logic required to draw a histogram
shinyServer(function(input, output) {

    # show instances
    output$inpInstData <- renderPrint({
        cat(paste(format(Sys.time(), "%a %b %d %Y %X")," \n"))
        cat(paste("Session ID : ",Sys.getpid()," \n"))
    })

    # slider input
    output$inpMonthNos <- renderUI({
        sliderInput("inpMonthNos", "Month Number",
                    min=5, max=9, value=5)
    })

    # slider input
    output$inpBinCount <- renderUI({
        sliderInput("inpBinCount", "Number COunt",
                    min=1, max=5, value=3)
    })

    # select input
    output$inpColNames <- renderUI({
        selectInput("inpColNames", label="Select Column",
                    choices=c("Ozone","Solar.R","Temp","Wind"), selected=1)
    })

    # render plot
    output$pltHistogram <- renderPlot({
        # plot cols
        intBinCount <- input$inpBinCount
        # select x-lab
        strXaxisLab <- input$inpColNames
        strPlotCols <- input$inpColNames
        # draw the histogram with the specified number of bins
        ggplot(dfrAirQuality, aes_string(x=input$inpColNames)) +
            geom_histogram(colour="blue", fill="blue", binwidth=intBinCount) +
            labs(title="Histogram Air Quality") +
            labs(x=strXaxisLab) +
            labs(y="Frequency Count")
    })

    # airquality - render data table
    output$datAirQulty <- renderDataTable({
        intMonthNos <- input$inpMonthNos
        dfrAirQulty <- filter(dfrAirQuality, Month==intMonthNos)
        dfrAirQulty
    },options = list(
        pageLength=10
        #aoColumnDefs=list(list(sClass="alignRight",aTargets=c(list(1),list(2),list(3),list(4),list(5))))
        #aoColumnDefs='[{"aTargets":[1,2,3], "sClass":"alignRight"}]'
    ))

    # show summary
    output$smrAirQulty <- renderPrint({
        intMonthNos <- input$inpMonthNos
        dfrAirQulty <- filter(dfrAirQuality, Month==intMonthNos)
        summary(dfrAirQulty)
    })


})