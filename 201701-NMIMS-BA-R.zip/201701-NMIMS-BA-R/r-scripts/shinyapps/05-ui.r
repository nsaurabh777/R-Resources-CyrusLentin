# 05-ui.r
# tableOutput / renderTable

# load library
library(shiny)

# Define UI for application that draws a histogram
shinyUI(fluidPage(

    # Application title
    titlePanel("Hello Shiny!"),

    # Sidebar with a slider input for the number of bins
    sidebarPanel(width=3,
        uiOutput("inpMonthNos")
    ),

    # Show a plot of the generated distribution
    mainPanel(width=9,
        tableOutput("datAirQulty")
    )
))