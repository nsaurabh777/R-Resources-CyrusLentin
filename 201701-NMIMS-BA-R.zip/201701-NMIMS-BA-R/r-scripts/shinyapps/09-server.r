# 09-server.r
# conditional display

# load library
library(shiny)
library(ggplot2)
library(dplyr)

# load dataset
dfrAirQuality <- airquality

#
glblInstance <- 0

# define server logic required to draw a histogram
shinyServer(function(input, output) {

    # show instances
    output$inpInstData <- renderPrint({
        cat(format(Sys.time(), "%a %b %d %Y %X")," \n")
        cat("Session ID : ",Sys.getpid()," \n")
    })

    # select input
    output$inpDispType <- renderUI({
        selectInput("inpDispType", label="Select Display",
                    choices=c("Graph","Data"), selected=1)
    })

    # slider input
    output$inpMonthNos <- renderUI({
        sliderInput("inpMonthNos", "Month Number",
                    min=5, max=9, value=5)
    })

    # slider input
    output$inpBinCount <- renderUI({
        sliderInput("inpBinCount", "Bin Count",
                    min=1, max=5, value=3)
    })

    # select input
    output$inpColNames <- renderUI({
        selectInput("inpColNames", label="Select Column",
                    choices=c("Ozone","Solar.R","Temp","Wind"), selected=1)
    })

    # select input
    output$inpDataType <- renderUI({
        selectInput("inpDataType", label="Display Data Using",
                    choices=c("Norm Table","Data Table"), selected=1)
    })

    # render plot
    output$pltHistogram <- renderPlot({
        # plot cols
        intBinCount <- input$inpBinCount
        # select x-lab
        strXaxisLab <- input$inpColNames
        strPlotCols <- input$inpColNames
        # draw the histogram with the specified number of bins
        ggplot(dfrAirQuality, aes_string(x=input$inpColNames)) +
            geom_histogram(colour="blue", fill="blue", binwidth=intBinCount) +
            labs(title="Histogram Air Quality") +
            labs(x=strXaxisLab) +
            labs(y="Frequency Count")
    })

    datFiltData <- reactive({
        intMonthNos <- input$inpMonthNos
        dfrAirQulty <- filter(dfrAirQuality, Month==intMonthNos)
        dfrAirQulty
    })

    # airquality - render table
    output$datAirQultyRT <- renderTable({
        datFiltData()
    }, align='rrrrrrr')


    # airquality - render data table
    output$datAirQultyRD <- renderDataTable({
        datFiltData()
    },options = list(
        pageLength=10
        #aoColumnDefs=list(list(sClass="alignRight",aTargets=c(list(1),list(2),list(3),list(4),list(5))))
        #aoColumnDefs='[{"aTargets":[1,2,3], "sClass":"alignRight"}]'
    ))

    # show summary
    output$smrAirQulty <- renderPrint({
        summary(datFiltData())
    })

})