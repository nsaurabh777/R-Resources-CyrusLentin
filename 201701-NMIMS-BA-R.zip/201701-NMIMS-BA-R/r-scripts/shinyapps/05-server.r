# 05-server.r
# tableOutput / renderTable

# load library
library(shiny)
library(ggplot2)
library(dplyr)

# load dataset
dfrAirQuality <- airquality

# define server logic required to draw a histogram
shinyServer(function(input, output) {

    # slider input
    output$inpMonthNos <- renderUI({
        sliderInput("inpMonthNos", "Month Number",
                    min=5, max=9, value=5)
    })

    # slider input
    output$inpBinCount <- renderUI({
        sliderInput("inpBinCount", "Number COunt",
                    min=1, max=5, value=3)
    })

    # select input
    output$inpColNames <- renderUI({
        selectInput("inpColNames", label="Select Column",
                    choices=c("Ozone","Solar.R","Temp","Wind"), selected=1)
    })

    # render plot
    output$pltHistogram <- renderPlot({
        # plot cols
        intBinCount <- input$inpBinCount
        # select x-lab
        strXaxisLab <- input$inpColNames
        strPlotCols <- input$inpColNames
        # draw the histogram with the specified number of bins
        ggplot(dfrAirQuality, aes_string(x=input$inpColNames)) +
            geom_histogram(colour="blue", fill="blue", binwidth=intBinCount) +
            labs(title="Histogram Air Quality") +
            labs(x=strXaxisLab) +
            labs(y="Frequency Count")
    })

    # airquality - render table
    output$datAirQulty <- renderTable({
        intMonthNos <- input$inpMonthNos
        dfrAirQulty <- filter(dfrAirQuality, Month==intMonthNos)
        dfrAirQulty
    }, align='rrrrrr')

})