# 10-server.r
# other controls - numerciInput, dateInput, textInput, passInput, textareaInput
# data validation

# sload library
library(shiny)
library(ggplot2)

# function to create our own multi-line control
textareaInput <- function(id, label, value, rows=3, cols=25, class="form-control"){
    tags$div(
        class="form-group shiny-input-container",
        tags$label('for'=id,label),
        tags$textarea(id=id,class=class,rows=rows,cols=cols,value))
}

# define server logic
# notice new param "session"
shinyServer(function(input, output, session) {

    # num input
    output$inpNumbData <- renderUI({
        numericInput("inpNumbData", "Enter Number", value=0, min=0, max=9999)
    })

    # dat input
    # caution only yyy-mm-dd seems to work
    output$inpDateData <- renderUI({
        dateInput("inpDateData", "Enter Date", value=Sys.Date(),
                    min=as.Date("2011-01-01"), max=as.Date("2020-12-31"),
                    format="yyyy-mm-dd")
    })

    # str input
    output$inpTextData <- renderUI({
        textInput("inpTextData", "Enter Text", value="")

    })

    # password input
    output$inpPassData <- renderUI({
        passwordInput("inpPassData", "Enter Password", value="")
    })

    # multi-line text area input
    output$inpTextArea <- renderUI({
        textareaInput("inpTextArea", "Enter In Text Area", rows=5, cols=25, value="")
    })

    # show output
    output$inpCheckData <- reactive({
        #get(input$data, 'package:datasets')
    })

    # show output
    output$inpShowData <- renderPrint({
        #validate(
        #    need(input$inpTextData!="", "Text Data Mandatory"),
        #    need(input$inpPassData!="", "Paasword Data Mandatory"),
        #    need(input$inpTextArea!="", "Text Area Data Mandatory")
        #)
        cat("Numeric Input   : ", input$inpNumbData, "\n")
        cat("Date Input      : ", format(input$inpDateData, "%a %d-%b-%Y"), "\n")
        cat("String Input    : ", input$inpTextData, "\n")
        cat("Password Input  : ", input$inpPassData, "\n")
        cat("Multiline Input : ", input$inpTextArea, "\n")
    })

})