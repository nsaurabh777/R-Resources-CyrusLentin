# 09-ui.r
# conditional display

# load library
library(shiny)

# Define UI for application that draws a histogram
shinyUI(fluidPage(

    # Application title
    titlePanel("Hello Shiny!"),

    # Sidebar with a slider input for the number of bins
    sidebarPanel(width=3,
        uiOutput("inpDispType"),
        conditionalPanel(condition="input.inpDispType=='Data'",uiOutput("inpMonthNos")),
        conditionalPanel(condition="input.inpDispType=='Data'",uiOutput("inpDataType")),
        conditionalPanel(condition="input.inpDispType=='Graph'",uiOutput("inpBinCount")),
        conditionalPanel(condition="input.inpDispType=='Graph'",uiOutput("inpColNames")),
        verbatimTextOutput("inpInstData")
    ),

    # Show a plot of the generated distribution
    mainPanel(width=9,
        #style sheet
        #tags$head(tags$style(".alignRight{align:right;}", media="all", type="text/css")),
        # show data
        conditionalPanel(condition="input.inpDispType=='Graph'",plotOutput("pltHistogram")),
        conditionalPanel(condition="input.inpDispType=='Data' && input.inpDataType=='Norm Table'",tableOutput("datAirQultyRT")),
        conditionalPanel(condition="input.inpDispType=='Data' && input.inpDataType=='Data Table'",dataTableOutput("datAirQultyRD")),
        verbatimTextOutput("smrAirQulty")
    )
))