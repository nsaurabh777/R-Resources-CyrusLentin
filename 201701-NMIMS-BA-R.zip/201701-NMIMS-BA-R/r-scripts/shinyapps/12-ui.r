# 11-ui.r
# function in shinyApp

# load library
library(shiny)

shinyUI(fluidPage(

	titlePanel("Uploading Files"),

 	sidebarPanel(
 	    uiOutput("inpFileName"),
		tags$hr(),
		uiOutput("inpHeadPres"),
		uiOutput("inpSepsChar"),
		uiOutput("inpQuotChar"),
		tags$b(p("File Info")),
		verbatimTextOutput("inpFileInfo")
    ),

    mainPanel(
        dataTableOutput('ShowData'),
        tableOutput('ShowTable')
    )

))