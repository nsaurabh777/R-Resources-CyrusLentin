# 11-server.r
# function with fileInput

# load library
library(shiny)

# IMPORTANT
# by default, the file size limit is 5MB. It can be changed by
# setting this option. Here we'll raise limit to 9MB.
options(shiny.maxRequestSize = 9*1024^2)

# server
shinyServer(function(input, output) {

    # header pres checkbox
    output$inpFileName <- renderUI({
        fileInput('inpFileName', 'Choose CSV File', accept=c('text/csv', 'text/comma-separated-values,text/plain', '.csv'))
    })

    # header pres checkbox
    output$inpHeadPres <- renderUI({
        checkboxInput('inpHeadPres', 'Header', TRUE)
    })

    # sperator char radio buttons
    output$inpSepsChar <- renderUI({
        radioButtons('inpSepsChar', 'Separator', c(Comma=',',Semicolon=';',Tab='\t'), ',')
    })

    # sperator char radio buttons
    output$inpQuotChar <- renderUI({
        radioButtons('inpQuotChar', 'Quote', c(None='','Double Quote'='"','Single Quote'="'"), '"')
    })

    # show file info
    output$inpFileInfo <- renderPrint({
        # move to local variable
        dfrFileName <- input$inpFileName
        # check for null
        # this handles initial run
        # where inpFileName = NULL
        if (is.null(dfrFileName))
            return(cat(" "))
        # if !NULL, fileInput return a data frame with following cols
        # 'name', 'size', 'type', and 'datapath' columns
        # how can we verify this
        # we store to global variable [IMPORTANT]
        gblFileName <<- dfrFileName
        # show file info
        # 'name', 'size', 'type', and 'datapath' columns
        cat("File Name : ", dfrFileName$name[1], " \n")
        cat("File Size : ", dfrFileName$size[1], " \n")
        cat("File Type : ", dfrFileName$type[1], " \n")
        cat("Data Path : ", dfrFileName$datapath[1]," \n")
    })

    # show data file selected
    output$ShowData <- renderDataTable({
        # read data
        dfrDataFile <- readDataFile()
        # return
        dfrDataFile
    })

    # show data file selected
    output$ShowTable <- renderTable({
        # read data
        dfrDataFile <- readDataFile()
        # return
        dfrDataFile
    })

    # read  data file selected
    readDataFile <- reactive({
        # move to local variable
        dfrFileName <- input$inpFileName
        # check for null
        if (is.null(dfrFileName))
            return(NULL)
        # open data file
        dfrDataFile <- read.csv(dfrFileName$datapath[1], header=input$inpHeadPres, sep=input$inpSepsChar, quote=input$inpQuotChar)
        # move file to wd()
        # subject to OS level permissions
        #file.rename(dfrFileName$datapath[1], dfrFileName$name[1])
        # return
        return(dfrDataFile)
    })

})