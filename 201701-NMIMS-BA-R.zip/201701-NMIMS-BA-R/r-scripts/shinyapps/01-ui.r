# 02-ui.r
# ur.r / server.r as seperate files
# slider input
# plotOutput & renderPlot
# notice where libraries & datasets are loaded
# shinyUI

# load library
library(shiny)

# Define UI for application that draws a histogram
shinyUI(fluidPage(

    # Application title
    titlePanel("Hello Shiny!"),

    # Sidebar with a slider input for the number of bins
    sidebarPanel(
		sliderInput("inpBinCount", "Number of bins:",
			min=1, max=17, value = 9)
	),

    # Show a plot of the generated distribution
    mainPanel(
        plotOutput("pltHistogram")
	)
))