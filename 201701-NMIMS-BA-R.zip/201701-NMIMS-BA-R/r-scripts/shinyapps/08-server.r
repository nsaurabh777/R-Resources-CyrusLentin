# 08-server.r
# use of functions in shiny
# concept - reactive / reactive functions

# load library
library(shiny)
library(ggplot2)
library(dplyr)

# load dataset
dfrAirQuality <- airquality

#
glblInstance <- 0

# define server logic required to draw a histogram
shinyServer(function(input, output) {

    # show instances
    output$inpInstData <- renderPrint({
        cat(paste(format(Sys.time(), "%a %b %d %Y %X")," \n"))
        cat(paste("Session ID : ",Sys.getpid()," \n"))
    })

    # slider input
    output$inpMonthNos <- renderUI({
        sliderInput("inpMonthNos", "Month Number",
                    min=5, max=9, value=5)
    })

    # slider input
    output$inpBinCount <- renderUI({
        sliderInput("inpBinCount", "Number COunt",
                    min=1, max=5, value=3)
    })

    # select input
    output$inpColNames <- renderUI({
        selectInput("inpColNames", label="Select Column",
                    choices=c("Ozone","Solar.R","Temp","Wind"), selected=1)
    })

    # render data table
    output$datAirQulty <- renderDataTable({
        datFiltData()
    },options = list(
        pageLength=10
        #aoColumnDefs=list(list(sClass="alignRight",aTargets=c(list(1),list(2),list(3),list(4),list(5))))
        #aoColumnDefs='[{"aTargets":[1,2,3], "sClass":"alignRight"}]'
    ))

    # show summary
    output$smrAirQulty <- renderPrint({
        summary(datFiltData())
    })

	# read & filter 
    datFiltData <- reactive({
        intMonthNos <- input$inpMonthNos
        dfrAirQultyFilt <- filter(dfrAirQuality, Month==intMonthNos)
        dfrAirQultyFilt
    })


})