# 02-server.r
# sliderInput & selectInput (drop-down listbox)

# load library
library(shiny)
library(ggplot2)

# load dataset
dfrAirQuality <- airquality

# define server logic required to draw a histogram
shinyServer(function(input, output) {

    # render plot
    output$pltHistogram <- renderPlot({

        # plot cols
        intBinCount <- input$inpBinCount
        # select cols & x-lab
        vctPlotCols <- numeric(0)
        strXaxisLab <- input$inpColNames
        if (input$inpColNames=='Ozone') {
            vctPlotCols <- dfrAirQuality$Ozone
            }
        if (input$inpColNames=='Solar.R') {
            vctPlotCols <- dfrAirQuality$Solar.R
            }
        if (input$inpColNames=='Temp') {
            vctPlotCols <- dfrAirQuality$Temp
            }
        if (input$inpColNames=='Wind') {
            vctPlotCols <- dfrAirQuality$Wind
            }
        # draw the histogram with the specified number of bins
        hist(vctPlotCols, breaks=intBinCount, col='blue', border='white',
            main="Histogram Air Quality",  ## title
            xlab=strXaxisLab,
            ylab="Frequency Count"       ## y-axis label
            )
    })
})