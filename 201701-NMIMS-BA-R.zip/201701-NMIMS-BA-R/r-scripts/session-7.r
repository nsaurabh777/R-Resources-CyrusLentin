#####
# script: session-7.r
# title : business analytic using r
# focus : ggplot2
# author: Cyrus Lentin
# date  : 01-Oct-2015
#####

# working dir
setwd("D:/BA-R/R-Scripts")

# clear environment & history
rm(list = ls())
write("", file=".blank")
loadhistory(".blank")
unlink(".blank")

#####
# libraries
####
install.packages("ggplot2")
library(ggplot2)

#####
# dataset
#####
cat("\014")
# explore data set to be used
dfrMtCars <- mtcars
# important to create labels
dfrMtCars$gear <- factor(dfrMtCars$gear,levels=c(3,4,5), labels=c("3gears","4gears","5gears"))
dfrMtCars$am   <- factor(dfrMtCars$am,levels=c(0,1), labels=c("Manual","Automatic"))
dfrMtCars$cyl  <- factor(dfrMtCars$cyl,levels=c(4,6,8), labels=c("4cyl","6cyl","8cyl"))
head(dfrMtCars)
nrow(dfrMtCars)

#####
# ggplot
#####

cat("\014")
# simple histogram
# requires numeric column as x-axis ... categoric / string column will give error
# y-axis is count within the bin (calulated)
# shows histogram
ggpGraph <- ggplot(dfrMtCars, aes(x=mpg))
ggpGraph <- ggpGraph + geom_histogram(colour="red", fill="red")
ggpGraph

cat("\014")
# simple histogram
ggpGraph <- ggplot(dfrMtCars, aes(x=mpg)) +
            geom_histogram(colour="red", fill="red", binwidth=2) +
            labs(title="Histogram Of Milage") +
            labs(x="Mileage MPG") +
            labs(y="Frequency Count")
ggpGraph


cat("\014")
# simple scatterplot
# requires numeric column as x-axis & numeric column as y-axis
# requires numeric column as x-axis & categoric  column as y-axis
# requires categoric column as x-axis & numeric column as y-axis
# categoric column as x-axis & y-axis shows "bad" data
# shows scatterplot
ggplot(dfrMtCars, aes(x=wt, y=mpg)) +
    geom_point(shape=19)      # default shape = 19 - medium solid disc
ggplot(dfrMtCars, aes(x=cyl, y=am)) +
    geom_point(shape=19)      # default shape = 19 - medium solid disc

cat("\014")
# simple scatterplot with annotations
ggplot(dfrMtCars, aes(x=wt, y=mpg)) +
    geom_point(shape=19, colour="red", fill="red") +
    labs(title="Scatterplot Example") +
    labs(x="Car Weight (Tons)") +
    labs(y="Miles Per Gallon")

cat("\014")
# facetted scatterplot with annotations
# requires numeric column as x-axis & numeric column as y-axis & group by categoric colum
# requires numeric column as x-axis & categoric  column as y-axis &  & group by categoric colum
# shows facetted scatterplot
ggplot(dfrMtCars, aes(x=wt, y=mpg)) +
    geom_point(shape=19, aes(colour=cyl, fill=cyl)) +
    facet_grid(. ~ cyl) +
    labs(title="Scatterplot Example") +
    labs(x="Car Weight (Tons)") +
    labs(y="Miles Per Gallon")

cat("\014")
# simple scatterplot with annotations & facets
ggplot(dfrMtCars, aes(x=wt, y=cyl)) +
    geom_point(shape=19, aes(colour=gear, fill=gear)) +
    facet_grid(. ~ gear) +
    labs(title="Scatterplot Example") +
    labs(x="Car Weight (Tons)") +
    labs(y="Miles Per Gallon")

cat("\014")
# simple boxplot
# requires categoric column as x-axis & numeric column as y-axis
# other combination shows "bad plot"
ggplot(dfrMtCars, aes(x=gear, y=mpg)) +
    geom_boxplot()

# boxplot of mpg by car cylinders
ggplot(dfrMtCars, aes(x=gear, y=mpg)) +
    geom_boxplot(aes(color=gear, fill=gear)) +
    labs(title="Car Milage Data") +
    labs(x="Number of Cylinders") +
    labs(y="Miles Per Gallon")

cat("\014")
# bar plot as histogram
# requires categoric column or string column (with repetetive data) as x-axis
# y-axis is count within the bin (calulated)
# shows histogram
ggplot(dfrMtCars, aes(x=xxx)) +
    geom_bar(stat="count")

cat("\014")
# simple bar plot with annotations
# providng x-axis variable as color & fill shows graph in different colors
ggplot(dfrMtCars, aes(x=gear)) +
    geom_bar(stat="count", aes(color=gear, fill=gear)) +
    labs(title="Car Distribution by Gears") +
    labs(x="Number of Gears") +
    labs(y="Frequency Count")

cat("\014")
# horizontal bar plot with annotations
# providing coord_flip() shows horizontal bar
ggplot(dfrMtCars, aes(x=gear)) +
    geom_bar(stat="count", aes(color=gear, fill=gear)) +
    labs(title="Car Distribution by Gears") +
    labs(x="Number of Gears") +
    labs(y="Frequency Count") +
    coord_flip()

cat("\014")
# stacked bar charts
# providng another categoric column as color & fill
# and specifiying geom_bar(position="stack")
# shows stacked bar based on the second column
# giving numeric column shows "bad plot"
# not specing geom_bar(position="stack") shows "bad plot"
ggplot(dfrMtCars, aes(x=gear, fill=am, color=am)) +
    geom_bar(position="stack") +
    labs(title="Car Distribution by Gears & AM") +
    labs(x="Number of Gears") +
    labs(y="Frequency Count")

cat("\014")
# group bar charts
# providng another categoric column as color & fill
# and specifiying geom_bar(position="dodge")
# shows group bar based on the second column
# giving numeric column shows "bad plot"
# not specing geom_bar(position="dodge") shows "bad plot"
# when one of the group item is zero the bar width is expanded
ggplot(dfrMtCars, aes(x=gear, fill=am, color=am)) +
    geom_bar(position="dodge") +
    labs(title="Car Distribution by Gears & AM") +
    labs(x="Number of Gears") +
    labs(y="Frequency Count")

cat("\014")
# read nifty
dfrNifty <- read.csv("./data/nifty-data.csv", header=T, stringsAsFactors=F)

cat("\014")
# simple bar plot with annotations using x & y data
# requires categoric column or string column (with repetetive data) as x-axis
# y-axis is corresponding value of x-axis
# important geom_bar(stat="identity"
# use aes(color=Symbol, fill=Symbol) to get different colors
# understand theme directive
# shows value bar plot
dfrNifty.Tmp <- dfrNifty[1:10,]
#intlevels <- length(unique(dfrNifty.Tmp$Symbol)) # in real world use this
ggplot(dfrNifty.Tmp, aes(x=Symbol, y=ClosePrice )) +
    #geom_bar(stat="identity", aes(color=rainbow(10), fill=rainbow(10))) +
    geom_bar(stat="identity", aes(color=Symbol, fill=Symbol))  +
    labs(title="Share Price On 01-Dec-2014") +
    labs(x="Script Name") +
    labs(y="Price") +
    theme(axis.text.x=element_text(angle=50,hjust=1,vjust=1))

cat("\014")
# grouped bar plot with annotations using x & y data (multiple series)
# prepare data ... keep only columns which are required
library(dplyr)
library(tidyr)
dfrNifty.Tmp <- dfrNifty[1:10,]
dfrNifty.Tmp <- select(dfrNifty.Tmp, Symbol, PrevClose, OpenPrice, ClosePrice)
dfrNifty.Tmp <- gather(dfrNifty.Tmp, Symbol)
names(dfrNifty.Tmp) <- c("Symbol","Vars","Vals")
# plot
# requires categoric column or string column (with repetetive data) as x-axis
# requires numeric column as y-axis
# requires another categoric column for grouping to be used with "fill"
# plots group bar-graph
ggplot(dfrNifty.Tmp, aes(x=Symbol, y=Vals, fill=Vars)) +
    geom_bar(stat="identity", position="dodge") +
    labs(title="Share Price On 01-Dec-2014") +
    labs(x="Script Name") +
    labs(y="Price") +
    theme(axis.text.x=element_text(angle=50,hjust=1,vjust=1))

cat("\014")
# simple line plot
# requires numeric column or date column as x-axis
# requires numeric column as y-axis
# plots line-graph
dfrNifty.Tmp <- subset(dfrNifty, Symbol=="ACC")
ggplot(dfrNifty.Tmp, aes(x=as.Date(DateDate), y=ClosePrice)) +
    geom_line(color="red") +
    geom_point(color="red", shape=19) +
    labs(title="Share Movement") +
    labs(x="Date") +
    labs(y="Closing Price")

cat("\014")
# multi line plot
# requires numeric column or date column (with repetetive data) as x-axis
# requires numeric column as y-axis
# requires another string column / categoric column for grouping to be used with "group"
# plots group bar-plot
dfrNifty.Tmp <- subset(dfrNifty, Symbol=="ACC" | Symbol=="LT" )
ggplot(dfrNifty.Tmp, aes(x=as.Date(DateDate), y=ClosePrice, group=Symbol)) +
    geom_line(aes(color=Symbol)) +
    geom_point(shape=19, size=1.75, aes(color=Symbol)) +
    labs(title="Share Movement") +
    labs(x="Date") +
    labs(y="Closing Price")


#####
# plot as an object
#####
cat("\014")
# simple bar plot with annotations using x & y data
dfrNifty.Tmp <- subset(dfrNifty, DateDate=="2014-12-01")
dfrNifty.Tmp <- dfrNifty.Tmp[1:10,]
ggpGraphObj <- ggplot(dfrNifty.Tmp, aes(x=Symbol, y=ClosePrice )) +
                geom_bar(stat="identity", aes(color=Symbol, fill=Symbol)) +
                labs(title="Share Price On 01-Dec-2014") +
                labs(x="Script Name") +
                labs(y="Price") +
                theme(axis.text.x=element_text(angle=50,hjust=1,vjust=1))
ggpGraphObj


cat("\014")
# multi line plot
dfrNifty.Tmp <- subset(dfrNifty, Symbol=="ACC" | Symbol=="LT" )
ggpGraphObj <- ggplot(dfrNifty.Tmp, aes(x=as.Date(DateDate), y=ClosePrice, group=Symbol))
ggpGraphObj <- ggpGraphObj + geom_line(aes(color=Symbol))
ggpGraphObj <- ggpGraphObj + geom_point(shape=19, size=1.75, aes(color=Symbol))
ggpGraphObj <- ggpGraphObj + labs(title="Share Movement")
ggpGraphObj <- ggpGraphObj + labs(x="Date")
ggpGraphObj <- ggpGraphObj + labs(y="Closing Price")
ggpGraphObj


#####
# qplot - begin
#####

cat("\014")
# simple histogram
# requires numeric column
# shows histogram
qplot(mpg, data=dfrMtCars, geom="histogram")

cat("\014")
# colored histogram with different number of bins & with annotations
qplot(mpg, data=dfrMtCars, geom="histogram", binwidth=3,
      fill=I("red"), color=I("red"),
      main = "Histogram Of Milage",  ## title
      xlab = "Mileage MPG",          ## x-axis label
      ylab = "Frequency Count"       ## y-axis label
)

cat("\014")
# simple scatterplot
# requires 2 numeric columns & dataframe
# shows scatter plot
qplot(wt,mpg, data=dfrMtCars)

cat("\014")
# simple scatterplot with annotations
qplot(wt,mpg, data=dfrMtCars,
      color=I("red"),
      #shape="19", # no easy way to change pch / shape
      main="Scatterplot Example",
      xlab="Car Weight (Tons)",
      ylab="Miles Per Gallon"
)

cat("\014")
# simple boxplot
# requires 1 numeric column, 1 categoric column & dataframe
# or
# requires 2 numeric column & dataframe
# shows boxplot
qplot(gear, mpg, data=dfrMtCars, geom="boxplot")

cat("\014")
# boxplot of wt by mpg
qplot(wt, mpg, data=dfrMtCars, geom="boxplot")

cat("\014")
# boxplot of mpg by car cylinders
qplot(gear, mpg, data=dfrMtCars, geom="boxplot",
      color=gear,
      #fill=gear,
      main="Car Milage Data",
      xlab="Number of Cylinders",
      ylab="Miles Per Gallon"
)

cat("\014")
# simple bar plot
# requires 1 categoric column
# shows histogram
qplot(gear, data=dfrMtCars, geom="bar")

cat("\014")
# simple bar plot with annotations
# requires 1 categoric column as data
# requires 1 categoric column as groups
# if group column same as data - simple bar
# generates histogram
qplot(gear, data=dfrMtCars, geom="bar",
      color=gear,
      fill=gear,
      main="Car Distribution by Gears",
      xlab="Number of Gears",
      ylab="Frequency Count"
)

cat("\014")
# stacked bar charts
# simple bar plot with annotations
# requires 1 categoric column as data
# requires 1 categoric column as groups (as given in color & fill)
# if group column NOT same as data - stacked bar
# generates histogram (based on group)
qplot(gear, data=dfrMtCars, geom="bar",
      color=am,
      fill=am,
      width=.1,
      main="Car Distribution by Gears",
      xlab="Number of Gears",
      ylab="Frequency Count"
)

# simple bar plot - value based
# --- NOT AVAILABLE in qplot use ggplot

# group bar plot - value based
# --- NOT AVAILABLE in qplot use ggplot

cat("\014")
# read nifty
dfrNifty <- read.csv("./data/nifty-data.csv", header=T, stringsAsFactors=F)
dfrNifty.Tmp <- dfrNifty[1:10,]

cat("\014")
# simple line plot
dfrNifty.Tmp <- subset(dfrNifty, Symbol=="ACC")
qplot(as.Date(DateDate), ClosePrice, data=dfrNifty.Tmp,
      colour = I("4"), geom="line",
      main="Share Movement",
      xlab="Date",
      ylab="Closing Price"
)

cat("\014")
# multi line plot
dfrNifty.Tmp <- subset(dfrNifty, Symbol=="ACC" | Symbol=="LT" )
qplot(as.Date(DateDate), ClosePrice, data=dfrNifty.Tmp, group=Symbol,
      colour=dfrNifty.Tmp$Symbol, geom=c("point", "line"),
      main="Share Movement",
      xlab="Date",
      ylab="Closing Price"
)


