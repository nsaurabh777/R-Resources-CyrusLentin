#####
# script: session-4.r
# title : business analytic using r
# focus : data manipulation using dplyr
# author: Cyrus Lentin
# date  : 01-Oct-2015
#####

# working dir
setwd("D:/R-BA/R-Scripts")

# clear environment & history
rm(list = ls())
write("", file=".blank")
loadhistory(".blank")
unlink(".blank")

#####
# dplyr package
####

cat("\014")
# install
#install.packages('dplyr')
#install.packages('tidyr')
#install.packages('data.table')
# load library
library(dplyr)
library(tidyr)
#library(data.table)

cat("\014")
# read nifty
dfrNifty <- read.csv("./data/nifty-data.csv", header=T, stringsAsFactors=F)
#dfrNifty <- data.table(dfrNifty)
nrow(dfrNifty)
View(dfrNifty)

#####
# filter
#####

cat("\014")
# subset of rows based on condition
dfrNifty.ACC <- filter(dfrNifty, Symbol == "ACC")
nrow(dfrNifty.ACC)
View(dfrNifty.ACC)

cat("\014")
# subset of rows based on AND condition
dfrNifty.Filt <- filter(dfrNifty, (dfrNifty$DateDate >= "2014-12-01" &
                    dfrNifty$DateDate <= "2014-12-05") )
nrow(dfrNifty.Filt)
View(dfrNifty.Filt)

cat("\014")
# subset of rows based on OR condition
dfrNifty.Filt <- filter(dfrNifty, (dfrNifty$DateDate == "2014-12-01" |
                    dfrNifty$DateDate == "2014-12-05") )
nrow(dfrNifty.Filt)
View(dfrNifty.Filt)

cat("\014")
# subset of rows based on "starts-with" condition ... start search string with ^
dfrNifty.Tmp <- slice(dfrNifty, 1:50)
dfrNifty.Filt <- filter(dfrNifty.Tmp, grepl("^TATA",dfrNifty.Tmp$NameOfTheSecurityInNse))
nrow(dfrNifty.Filt)
View(dfrNifty.Filt)

cat("\014")
# subset of rows based on "ends-with" condition ... end search string with $
dfrNifty.Tmp <- slice(dfrNifty, 1:50)
dfrNifty.Filt <- filter(dfrNifty.Tmp, grepl("LTD$",dfrNifty.Tmp$NameOfTheSecurityInNse))
nrow(dfrNifty.Filt)
View(dfrNifty.Filt)

cat("\014")
# subset of rows based on "contains" condition ... end search string with +
dfrNifty.Tmp <- slice(dfrNifty, 1:50)
dfrNifty.Filt <- filter(dfrNifty.Tmp, !grepl("BANK+",dfrNifty.Tmp$Symbol))
nrow(dfrNifty.Filt)
View(dfrNifty.Filt)

#####
# slice()
#####

cat("\014")
# subset of rows by position or row-number ... first row
dfrNifty.Slcd <- slice(dfrNifty, 1)
nrow(dfrNifty.Slcd)
View(dfrNifty.Slcd)

cat("\014")
# subset of rows by position or row-range ... by row no range
dfrNifty.Slcd <- slice(dfrNifty, 1:10)
nrow(dfrNifty.Slcd)
View(dfrNifty.Slcd)

cat("\014")
# subset of rows by position or row-range ... last 10
fr <- as.integer(nrow(dfrNifty)-9)
to <- nrow(dfrNifty)
dfrNifty.Slcd <- slice(dfrNifty, fr:to)
nrow(dfrNifty.Slcd)
View(dfrNifty.Slcd)

#####
# select
#####

cat("\014")
# subset of cols by col-names
dfrNifty.Subs <- select(dfrNifty, DateDate,Symbol,PrevClose)
ncol(dfrNifty.Subs)
View(dfrNifty.Subs)

cat("\014")
# subset of cols by col-names
dfrNifty.Subs <- select(dfrNifty, DateDate,Symbol,ends_with("Price"))
ncol(dfrNifty.Subs)
View(dfrNifty.Subs)

cat("\014")
# subset of cols by col-names
dfrNifty.Subs <- select(dfrNifty, DateDate,Symbol,starts_with("Trade"))
ncol(dfrNifty.Subs)
View(dfrNifty.Subs)

cat("\014")
# subset of cols by col-names
dfrNifty.Subs <- select(dfrNifty, DateDate,Symbol,contains("OfThe"))
ncol(dfrNifty.Subs)
View(dfrNifty.Subs)

cat("\014")
# drop / deleted col-names
dfrNifty.Dels <- select(dfrNifty, -IndSec, -CoprInd)
ncol(dfrNifty.Dels)
View(dfrNifty.Dels)

#####
# arrange
# sort based on column or multiple columns
# permanant sort - can not get back original order
#####

cat("\014")
dfrNifty.Sort <- arrange(dfrNifty, Symbol, DateDate)
View(dfrNifty.Sort)

cat("\014")
dfrNifty.Sort <- arrange(dfrNifty, desc(Symbol), desc(DateDate) )
View(dfrNifty.Sort)

cat("\014")
dfrNifty.Sort <- arrange(dfrNifty, Symbol, desc(TradeValue))
View(dfrNifty.Sort)

#####
# rename
# renames a specified column
#####

cat("\014")
dfrNifty.New <- rename(dfrNifty, Date=DateDate)
View(dfrNifty.New)

cat("\014")
dfrNifty <- rename(dfrNifty, Date=DateDate)
View(dfrNifty.New)

cat("\014")
dfrNifty <- rename(dfrNifty, DateDate=Date)
View(dfrNifty.New)

#####
# distinct
# filter unique / distinct rows
#####

cat("\014")
dfrNifty.Symbols <- distinct(dfrNifty, Symbol)
nrow(dfrNifty.Symbols)
View(dfrNifty.Symbols)

cat("\014")
dfrNifty.Symbols <- select(dfrNifty.Symbols, Symbol)
nrow(dfrNifty.Symbols)
View(dfrNifty.Symbols)

#####
# mutate
# add new column; existing columns remain as it is
#####

cat("\014")
dfrNifty.New <- mutate(dfrNifty,
                       HiLoAvg=((HighPrice+LowPrice)/2)
                )
View(dfrNifty.New)

cat("\014")
dfrNifty.New <- mutate(dfrNifty,
                        HiLoDif=(HighPrice-LowPrice),
                        HiLoAvg=((HighPrice+LowPrice)/2),
                        VolIndex=(HiLoDif*100/HiLoAvg)
                )
View(dfrNifty.New)

cat("\014")
dfrNifty.New <- select(dfrNifty.New, -HiLoDif, -HiLoAvg)
dfrNifty.New <- arrange(dfrNifty.New, desc(VolIndex))
View(dfrNifty.New)


#####
# transmute
# add new column; only specified columns remain rest are dropped
#####
cat("\014")
dfrNifty.New <- transmute(dfrNifty,
                        DateDate, Symbol, HiLoAvg=((HighPrice+LowPrice)/2)
                )
View(dfrNifty.New)

cat("\014")
dfrNifty.New <- transmute(dfrNifty,
                          DateDate, Symbol, PrevClose
                )
View(dfrNifty.New)

#####
# sample_n
# random n rows
#####
cat("\014")
set.seed(0)
dfrNifty.New <- sample_n(dfrNifty, 10)
View(dfrNifty.New)

#####
# sample_frac
# random %n rows
#####
cat("\014")
set.seed(0)
dfrNifty.New <- sample_frac(dfrNifty, 0.1)
View(dfrNifty.New)

#####
# joins
# joins two data frames following rules of join-sql
#####
dfrSalesEmps <- read.csv("./data/sales-emps.csv", header=T, stringsAsFactors=F)
dfrSalesItms <- read.csv("./data/sales-itms.csv", header=T, stringsAsFactors=F)

cat("\014")
dfrJoined <- inner_join(dfrSalesEmps, dfrSalesItms)
View(dfrJoined)

cat("\014")
dfrJoined <- left_join(dfrSalesEmps, dfrSalesItms)
View(dfrJoined)

cat("\014")
dfrJoined <- right_join(dfrSalesEmps, dfrSalesItms)
View(dfrJoined)

cat("\014")
dfrJoined <- full_join(dfrSalesEmps, dfrSalesItms)
View(dfrJoined)

cat("\014")
dfrJoined <- anti_join(dfrSalesEmps, dfrSalesItms)
View(dfrJoined)


#####
# summarise
#####

cat("\014")
summarise(dfrNifty, mean(HighPrice), mean(LowPrice))

cat("\014")
summarise(dfrNifty, sum(HighPrice), sum(LowPrice))

cat("\014")
summarise(dfrNifty, max(HighPrice), max(LowPrice))

cat("\014")
summarise(dfrNifty, min(HighPrice), min(LowPrice))

#####
# group by
#####

cat("\014")
dfrNifty.Group <- group_by(dfrNifty, Symbol)

cat("\014")
summarise(dfrNifty.Group, mean(HighPrice), mean(LowPrice))

cat("\014")
summarise(dfrNifty.Group, sum(HighPrice), sum(LowPrice))

cat("\014")
summarise(dfrNifty.Group, max(HighPrice), max(LowPrice))

cat("\014")
summarise(dfrNifty.Group, min(HighPrice), min(LowPrice))


#####
# summarise again
#####

cat("\014")
summarise(group_by(dfrNifty, Symbol), mean(HighPrice), mean(LowPrice))

cat("\014")
summarise(group_by(dfrNifty, Symbol), sum(HighPrice), sum(LowPrice))

cat("\014")
summarise(group_by(dfrNifty, Symbol), max(HighPrice), max(LowPrice))

cat("\014")
summarise(group_by(dfrNifty, Symbol), min(HighPrice), min(LowPrice))


#####
# chaining
#####

cat("\014")
dfrNifty.Group <- dfrNifty %>%
                  group_by(Symbol) %>%
                  summarise(max(HighPrice),min(HighPrice))
View(dfrNifty.Group)

cat("\014")
dfrNifty.New <- dfrNifty %>%
                select(DateDate, Symbol, HighPrice, LowPrice) %>%
                mutate(HiLoAvg=((HighPrice+LowPrice)/2)) %>%
                select(-HighPrice, -LowPrice)
View(dfrNifty.New)


#####
# merging data frames
#####

cat("\014")
# rbind()
# important cols of all data.frames should be same
set.seed(0)
dfrTest.1 <- data.frame(foo=1:10, bar=runif(10, min=0, max=10), buf=rnorm(10))
dfrTest.2 <- data.frame(foo=1:10, bar=runif(10, min=0, max=10), buf=rnorm(10))
dfrTest.F <- rbind(dfrTest.1, dfrTest.2)

cat("\014")
# cbind()
# important
set.seed(0)
dfrTest.1 <- data.frame(foo=1:10, bar.1=runif(10, min=0, max=10), buf.1=rnorm(10))
dfrTest.2 <- data.frame(foo=1:5, bar.2=runif(5, min=0, max=10), buf.2=rnorm(5))
dfrTest.F1 <- cbind(dfrTest.1, dfrTest.2)
dfrTest.F2 <- cbind(dfrTest.1, dfrTest.2, new="abc")
dfrTest.F3 <- merge(dfrTest.1, dfrTest.2, by="foo")


#####
# gather - convert report / pivot format into raw data rows
# spread - convert raw data rows into report / pivot format
#####

cat("\014")
# gather
dfrIipData <- read.csv("./data/iip-data.csv", header=T, stringsAsFactors=F)
dfrIipData.New <- dfrIipData %>%
                    rename(M.2015.07=X2015.07, M.2015.06=X2015.06, M.2015.05=X2015.05, M.2015.04=X2015.04) %>%
                    gather(Month, Data, -Item.Description) %>%
                    select(Month, Item.Description, Data)

cat("\014")
# spread
dfrIipData.Rep <- dfrIipData.New %>%
                    spread(Month, Data)


#####
# which & match
#####

cat("\014")
# which with vector
vciX <- c(1, 2, NA, 4, NA, 5,2)
vciX
which(is.na(vciX))
which(vciX==2)
match(is.na(vciX),vciX)
match(2,vciX)

cat("\014")
# which with data.frame column
dfrNifty <- read.csv("./data/nifty-data.csv", header=T, stringsAsFactors=F)
which(Symbol=="ACC")
which(dfrNifty$Symbol=="ACC")
match("ACC",dfrNifty$Symbol)

cat("\014")
# use airquality dataset
library(datasets)
head(airquality)
which(is.na(airquality$Ozone))
match(6, airquality$Month)
which(airquality$Month==6 & airquality$Day==6)

#####
# lapply / sapply
#####

cat("\014")
# lapply on list
lstX <- list(a = 1:4, b = rnorm(10), c = rnorm(20, 1), d = rnorm(100, 5))
lstX
x <- lapply(lstX, mean)
x
class(x)

cat("\014")
# sapply on list
x <- c( mean(lstX$a), mean(lstX$b), mean(lstX$c), mean(lstX$d) )
x
class(x)
x <- sapply(lstX, mean)
x
class(x)

cat("\014")
# use sapply on dataframe
head(dfrNifty)
sapply(dfrNifty[,6:10], mean)
sapply(dfrNifty[,6:10], max)
sapply(dfrNifty[,6:10], min)
sapply(dfrNifty[,6:10], median)

cat("\014")
# assign values to data.frame$columns
dfrNifty$CoprInd <- "Zer"
View(dfrNifty)

cat("\014")
# problem defination - assign conditional values to column
# ifelse(dfrNifty$Trades>=50000,"HighTrade","LowTrade")
# use sapply / mapply to traverse through dataframe rows
# use sapply when dealing with single column as arguments

# option 1 - user defined function
getTrade <- function(t) {
    strRetValue <- ifelse(t>=50000,"HighTrade","LowTrade")
    return (strRetValue)
}
dfrNifty$CoprInd <- sapply(dfrNifty$Trades,getTrade)
View(dfrNifty)
# blank the value
dfrNifty$CoprInd <- ""
View(dfrNifty)
# option 2 - inline function within sapply
dfrNifty$CoprInd <- sapply(dfrNifty$Trades,
                    FUN=function(t)
                    ifelse(t>=50000,"HighTrade","LowTrade")
                    )
View(dfrNifty)


cat("\014")
# problem defination - assign conditional values to column
# ifelse(dfrNifty$PrevClose>dfrNifty$ClosePrice,"Neg","Pos")
# use mapply to traverse through dataframe rows
# use mapply with multiple args

# option 1 - user defined function
getPosNeg <- function(pc,cp) {
    strRetValue <- ifelse(pc>cp,"Neg","Pos")
    return (strRetValue)
}
dfrNifty$CoprInd <- mapply(getPosNeg,
                    dfrNifty$PrevClose,
                    dfrNifty$ClosePrice
                    )
View(dfrNifty)
# blank the value
dfrNifty$CoprInd <- ""
View(dfrNifty)
# option 2 - inline function within mapply
dfrNifty$CoprInd <- mapply(FUN=function(pc,cp)ifelse(pc>cp,"Neg","Pos"),
                           dfrNifty$PrevClose,
                           dfrNifty$ClosePrice
)
View(dfrNifty)

cat("\014")
# problem defination - assign conditional values to column
# ifelse(dfrNifty$PrevClose>dfrNifty$ClosePrice,"Neg","Pos")
# use sapply to traverse through dataframe rows
# use sapply with row-number as argument
dfrNifty$IndSec  <- sapply(as.numeric(rownames(dfrNifty)),
        FUN=function(r)
        ifelse(dfrNifty[r,]$PrevClose>dfrNifty[r,]$ClosePrice,"Neg","Pos")
        )
View(dfrNifty)
