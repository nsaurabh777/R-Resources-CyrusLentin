#####
# script: session-9.r
# title : business analytic using r
# focus : shiny app
# author: Cyrus Lentin
# date  : 01-Oct-2015
#####

# working dir
setwd("D:/R-BA/R-Scripts")

# clear environment & history
rm(list = ls())
write("", file=".blank")
loadhistory(".blank")
unlink(".blank")

#####
# libraries
####
install.packages('devtools')
install.packages('rsconnect')
install.packages('shiny')

#install.packages('devtools', dependencies=T, repos='http://cran.rstudio.com/')
#devtools::install_github('rstudio/rsconnect')
#install.packages('rsconnect', dependencies=T, repos='http://cran.rstudio.com/')
#install.packages('shiny', dependencies=T, repos='http://cran.rstudio.com/')
library(rsconnect)
library(shiny)
#rsconnect::setAccountInfo(name='username', token='token', secret='secretkey')

